package com.serasaconsumidor.antifraude.score.batch.controller;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;
import java.util.Objects;

import com.serasaconsumidor.antifraude.score.batch.controller.exception.ClientException;
import com.serasaconsumidor.antifraude.score.batch.service.CreateTaskService;
import com.serasaconsumidor.antifraude.score.batch.service.DeleteTaskService;

@RestController
@RequestMapping("v1/tasks")
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class TaskController {

    Map<String, CreateTaskService> createTaskServiceMap;
    Map<String, DeleteTaskService> deleteTaskServiceMap;

    @PostMapping("/{job}")
    public ResponseEntity<Void> create(@PathVariable String job) {
        var jobName = String.format("CREATE_%s", job);
        CreateTaskService invokeJobService = createTaskServiceMap.get(jobName);

        if (Objects.isNull(invokeJobService)) {
            throw new ClientException(HttpStatus.UNPROCESSABLE_ENTITY, "Invalid job");
        }

        invokeJobService.execute();
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/{job}")
    public ResponseEntity<Void> delete(@PathVariable String job) {
        var jobName = String.format("DELETE_%s", job);
        DeleteTaskService deleteTaskService = deleteTaskServiceMap.get(jobName);

        if (Objects.isNull(deleteTaskService)) {
            throw new ClientException(HttpStatus.UNPROCESSABLE_ENTITY, "Invalid job");
        }

        deleteTaskService.execute();
        return ResponseEntity.noContent().build();
    }
}
