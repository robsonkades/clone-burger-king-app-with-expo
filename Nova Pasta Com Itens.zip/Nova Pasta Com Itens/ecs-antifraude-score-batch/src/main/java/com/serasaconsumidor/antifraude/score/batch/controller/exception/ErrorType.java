package com.serasaconsumidor.antifraude.score.batch.controller.exception;

import lombok.Getter;

@Getter
public enum ErrorType {

    INVALID_DATA("/dados-invalidos", "Invalid data"),
    INTERNAL_ERROR("/erro-de-sistema", "Internal error"),
    RESOURCE_NOT_FOUND("/recurso-nao-encontrado", "Resource not found");

    private String title;
    private String uri;

    ErrorType(String path, String title) {
        this.uri = "https://serasa.com.br/premium" + path;
        this.title = title;
    }
}

