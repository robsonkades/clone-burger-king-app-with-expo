package com.serasaconsumidor.antifraude.score.batch.config.aws.sns;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.amazonaws.services.sns.AmazonSNSAsync;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.util.HashMap;
import java.util.Map;

import com.serasaconsumidor.antifraude.score.batch.dto.MessageEventProducerDto;

@Service
@Slf4j
@AllArgsConstructor
public class SnsProducerImpl implements SnsProducer {

    private final AmazonSNSAsync amazonSNSAsync;

    @Override
    public void sendMessage(final Object message, final String topicArn, final String eventType) {
        try {
            Map<String, MessageAttributeValue> attributes = new HashMap<>();
            attributes.put("X-Event-Type", new MessageAttributeValue()
                    .withDataType("String")
                    .withStringValue(eventType));

            MessageEventProducerDto messageDto = MessageEventProducerDto.builder()
                    .data(message)
                    .build();

            var objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());

            String messageAsJson = objectMapper.writeValueAsString(messageDto);

            PublishRequest publishRequest = new PublishRequest()
                    .withMessageAttributes(attributes)
                    .withTopicArn(topicArn)
                    .withMessage(messageAsJson);

            amazonSNSAsync.publishAsync(publishRequest).get();
        } catch (Exception ex) {
            log.error("Error communicating with Amazon SNS Async API. HttpStatus: {} Error: {}", HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
        }
    }
}
