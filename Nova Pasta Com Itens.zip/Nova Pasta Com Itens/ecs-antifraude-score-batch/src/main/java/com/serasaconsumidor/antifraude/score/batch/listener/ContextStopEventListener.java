package com.serasaconsumidor.antifraude.score.batch.listener;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Component;

@Component
@AllArgsConstructor
@Slf4j
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ContextStopEventListener implements ApplicationListener<ContextClosedEvent> {

    JobExplorer jobExplorer;
    JobOperator jobOperator;

    @Override
    public void onApplicationEvent(ContextClosedEvent contextClosedEvent) {
        try {
            for(String job: jobExplorer.getJobNames()){
                for(Long id: jobOperator.getRunningExecutions(job)) {
                    jobOperator.stop(id);
                }
            }
        } catch (Exception e) {
            log.error("Error on stop event {}", e);
        }
    }
}
