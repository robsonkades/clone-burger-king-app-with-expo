package com.serasaconsumidor.antifraude.score.batch.config.security;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "security.encryption")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SecurityConfig {
    String cryptoIv;
    String cryptoKey;
}
