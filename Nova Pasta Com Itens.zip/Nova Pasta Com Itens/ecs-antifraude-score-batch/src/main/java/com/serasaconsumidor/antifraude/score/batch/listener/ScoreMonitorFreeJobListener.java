package com.serasaconsumidor.antifraude.score.batch.listener;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

import com.serasaconsumidor.antifraude.score.batch.config.ApplicationConfig;
import com.serasaconsumidor.antifraude.score.batch.config.aws.sns.SnsProducer;
import com.serasaconsumidor.antifraude.score.batch.config.aws.sns.TopicProperties;
import com.serasaconsumidor.antifraude.score.batch.dto.ScoreBatchEventDto;
import com.serasaconsumidor.antifraude.score.batch.dto.StackEventDataDto;
import com.serasaconsumidor.antifraude.score.batch.dto.StackEventDto;
import com.serasaconsumidor.antifraude.score.batch.event.EventType;
import com.serasaconsumidor.antifraude.score.batch.event.FilterType;

@Component("scoreMonitorFreeJobListener")
@Slf4j
@AllArgsConstructor
public class ScoreMonitorFreeJobListener extends JobExecutionListenerSupport {

    SnsProducer snsProducer;
    ApplicationConfig applicationConfig;
    TopicProperties topicProperties;

    @Override
    public void beforeJob(JobExecution jobExecution) {
        var  event = ScoreBatchEventDto
                .builder()
                .date(LocalDateTime.now().toString())
                .type("START")
                .build();

        var data = StackEventDataDto
                .builder()
                .saf(event)
                .build();

        var message = StackEventDto
                .builder()
                .clientOrigin(applicationConfig.getClient())
                .serviceOrigin(applicationConfig.getName())
                .eventCode(EventType.FREE_SCORE_BATCH)
                .userType("PF")
                .data(data)
                .build();

        snsProducer.sendMessage(message, topicProperties.getArnStackEvents(), FilterType.STACK_EVENTS_SNS_FILTER);
    }

    @Override
    public void afterJob(JobExecution jobExecution) {
        var  event = ScoreBatchEventDto
                .builder()
                .date(LocalDateTime.now().toString())
                .type("END")
                .build();

        var data = StackEventDataDto
                .builder()
                .saf(event)
                .build();

        var message = StackEventDto
                .builder()
                .clientOrigin(applicationConfig.getClient())
                .serviceOrigin(applicationConfig.getName())
                .eventCode(EventType.FREE_SCORE_BATCH)
                .userType("PF")
                .data(data)
                .build();

        snsProducer.sendMessage(message, topicProperties.getArnStackEvents(), FilterType.STACK_EVENTS_SNS_FILTER);
    }
}
