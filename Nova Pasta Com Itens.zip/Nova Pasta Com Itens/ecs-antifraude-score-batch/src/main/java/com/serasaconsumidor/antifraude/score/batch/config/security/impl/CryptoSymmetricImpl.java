package com.serasaconsumidor.antifraude.score.batch.config.security.impl;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.util.Base64;

import com.serasaconsumidor.antifraude.score.batch.config.security.CryptoSymmetric;

public class CryptoSymmetricImpl implements CryptoSymmetric {

    private String cryptIv;
    private SecretKeySpec cryptKey;

    public CryptoSymmetricImpl(String cryptIv, String cryptKey) {
        this.cryptIv = cryptIv;
        this.cryptKey = createSecretKey(cryptKey);
    }

    public String encrypt(String string) {
        if (string == null)
            return null;

        Cipher ciph;
        try {
            ciph = Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
            ciph.init(Cipher.ENCRYPT_MODE, cryptKey, new IvParameterSpec(cryptIv.getBytes(StandardCharsets.UTF_8)));
            return base64Encode(ciph.doFinal(string.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException | NoSuchProviderException | NoSuchPaddingException
                | InvalidKeyException | InvalidAlgorithmParameterException
                | IllegalBlockSizeException | BadPaddingException e) {
            throw new SecurityException("Error encrypting data", e);
        }
    }

    public String decrypt(String string) {
        if (string == null)
            return null;

        Cipher ciph;
        try {
            ciph = Cipher.getInstance("AES/CBC/PKCS5Padding", "SunJCE");
            ciph.init(Cipher.DECRYPT_MODE, cryptKey, new IvParameterSpec(cryptIv.getBytes(StandardCharsets.UTF_8)));
            return new String(ciph.doFinal(base64Decode(string)), StandardCharsets.UTF_8);
        } catch (NoSuchAlgorithmException | NoSuchProviderException | NoSuchPaddingException | InvalidKeyException | InvalidAlgorithmParameterException | IllegalBlockSizeException | BadPaddingException e) {
            throw new SecurityException("Error encrypting data", e);
        }
    }

    private static SecretKeySpec createSecretKey(String password) {
        return new SecretKeySpec(hexStringToByteArray(password), "AES");
    }

    private static byte[] hexStringToByteArray(String s) {
        int len = s.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(s.charAt(i), 16) << 4)
                    + Character.digit(s.charAt(i + 1), 16));
        }
        return data;
    }

    private static String base64Encode(byte[] bytes) {
        return Base64.getEncoder().encodeToString(bytes);
    }

    private static byte[] base64Decode(String property) {
        return Base64.getDecoder().decode(property);
    }
}