package com.serasaconsumidor.antifraude.score.batch.service.impl;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.serasaconsumidor.antifraude.score.batch.service.CreateTaskService;

@Service("CREATE_SCORE_MONITOR_FREE")
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class CreateTaskScoreMonitorFreeServiceImpl implements CreateTaskService {

    JobLauncher jobLauncher;
    @Qualifier(value = "scoreMonitorFreeJob")
    Job job;

    @Override
    @Async
    public void execute() {
        try {
            JobParameters jobParameters = new JobParametersBuilder().addLong("time",System.currentTimeMillis()).toJobParameters();
            jobLauncher.run(job, jobParameters);
        } catch (Exception e) {
            log.error("Error on starting job {} ", e);
        }
    }
}
