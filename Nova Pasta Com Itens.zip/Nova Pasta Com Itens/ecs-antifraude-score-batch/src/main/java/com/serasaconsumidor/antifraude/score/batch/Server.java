package com.serasaconsumidor.antifraude.score.batch;

import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;

import com.amazonaws.SDKGlobalConfiguration;

@SpringBootApplication
@EnableBatchProcessing
@EnableAsync
@EnableRetry
public class Server {
	public static void main(String[] args) {
		System.setProperty(SDKGlobalConfiguration.DISABLE_CERT_CHECKING_SYSTEM_PROPERTY, "true");
		SpringApplication.run(Server.class, args);
	}
}
