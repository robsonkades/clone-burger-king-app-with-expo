package com.serasaconsumidor.antifraude.score.batch.dto;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

import java.time.LocalDate;
import java.time.OffsetDateTime;

import com.serasaconsumidor.antifraude.score.batch.util.CustomOffsetDateTimeDeserializer;
import com.serasaconsumidor.antifraude.score.batch.util.CustomOffsetDateTimeSerializer;
import com.serasaconsumidor.antifraude.score.batch.util.CustomOffsetLocalDateDeserializer;
import com.serasaconsumidor.antifraude.score.batch.util.CustomOffsetLocalDateSerializer;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@Slf4j
public class RequestScoreMessageDto {

    @NotNull
    private String score;

    @JsonProperty("updated_at")
    @JsonSerialize(using = CustomOffsetDateTimeSerializer.class)
    @JsonDeserialize(using = CustomOffsetDateTimeDeserializer.class)
    @NotNull
    private OffsetDateTime updatedAt;

    @JsonProperty("dt_t0")
    @JsonSerialize(using = CustomOffsetLocalDateSerializer.class)
    @JsonDeserialize(using = CustomOffsetLocalDateDeserializer.class)
    @NotNull
    private LocalDate date;

    public static RequestScoreMessageDto fromJson(String json) {
        try {
            var objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            return objectMapper.readValue(json, RequestScoreMessageDto.class);
        } catch (Exception ex) {
            log.error("Error on readValue {}", ex);
            throw new RuntimeException(ex.getMessage());
        }
    }
}
