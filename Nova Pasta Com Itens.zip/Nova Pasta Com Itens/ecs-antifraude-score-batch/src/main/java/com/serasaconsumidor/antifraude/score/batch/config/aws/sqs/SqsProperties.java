package com.serasaconsumidor.antifraude.score.batch.config.aws.sqs;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "aws.sqs")
@FieldDefaults(level = AccessLevel.PRIVATE)
public class SqsProperties {
    String concurrency;
}
