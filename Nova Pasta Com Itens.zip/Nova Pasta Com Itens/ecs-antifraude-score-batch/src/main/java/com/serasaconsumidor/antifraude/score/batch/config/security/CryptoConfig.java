package com.serasaconsumidor.antifraude.score.batch.config.security;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.serasaconsumidor.antifraude.score.batch.config.security.impl.CryptoSymmetricImpl;

@Configuration
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class CryptoConfig {

    SecurityConfig config;

    @Bean
    public CryptoSymmetricImpl cryptoSymmetric() {
        return new CryptoSymmetricImpl(config.getCryptoIv(), config.getCryptoKey());
    }
}
