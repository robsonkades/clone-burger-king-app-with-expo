package com.serasaconsumidor.antifraude.score.batch.service.impl;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.serasaconsumidor.antifraude.score.batch.controller.exception.ClientException;
import com.serasaconsumidor.antifraude.score.batch.service.DeleteTaskService;

@Service("DELETE_SCORE_MONITOR_FREE")
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@Slf4j
public class DeleteTaskScoreMonitorFreeServiceImpl implements DeleteTaskService {

    JobOperator jobOperator;

    @Override
    @Async
    public void execute() {
        try {
            for(Long i: jobOperator.getRunningExecutions("scoreMonitorFreeJob")) {
                jobOperator.stop(i);
            }
        } catch (Exception e) {
            throw new ClientException(HttpStatus.BAD_REQUEST, e.getMessage());
        }
    }
}
