package com.serasaconsumidor.antifraude.score.batch.config.context;

public enum DatabaseEnvironment {
    UPDATABLE,READONLY
}
