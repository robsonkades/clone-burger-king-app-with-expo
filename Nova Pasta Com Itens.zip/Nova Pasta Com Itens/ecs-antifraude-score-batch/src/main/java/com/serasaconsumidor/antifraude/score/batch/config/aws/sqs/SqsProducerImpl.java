package com.serasaconsumidor.antifraude.score.batch.config.aws.sqs;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.SendMessageBatchRequest;
import com.amazonaws.services.sqs.model.SendMessageBatchRequestEntry;
import com.amazonaws.services.sqs.model.SendMessageBatchResult;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.google.common.collect.Lists;

import java.time.Duration;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import com.serasaconsumidor.antifraude.score.batch.dto.MessageEventProducerDto;

@Slf4j
@Service
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class SqsProducerImpl implements SqsProducer {

    AmazonSQS sqsClient;

    private static final Integer DELAY = 5;

    @Override
    public <T> void sendMessage(T message, String queue) {
        try {
            var sendMessageRequest = new SendMessageRequest()
                    .withQueueUrl(queue)
                    .withDelaySeconds(Duration.ofMinutes(DELAY).toSecondsPart())
                    .withMessageBody(toJson(message));

            var response = sqsClient.sendMessage(sendMessageRequest);
            log.debug("Message send to SQS with message id: {}", response.getMessageId());
        } catch (Exception e) {
            log.error("Error send message to SQS, {}", e.getMessage());
        }
    }

    @Override
    public void sendMessageBatch(List<?> messages, String queue) {

        List<String> messagesJson = messages
                .stream()
                .map(this::toJson)
                .filter(item -> !StringUtils.isEmpty(item))
                .collect(Collectors.toList());

        Lists.partition(messagesJson, 10)
                .parallelStream().forEach(strings -> {
            try {
                final AtomicInteger index = new AtomicInteger();
                final List<SendMessageBatchRequestEntry> entries = strings.stream()
                        .map(message -> {
                            final String messageId = String.valueOf(index.getAndIncrement());
                            var request = new SendMessageBatchRequestEntry(messageId, message);
                            request.setDelaySeconds(Duration.ofMinutes(DELAY).toSecondsPart());
                            return request;
                        }).collect(Collectors.toList());

                var sendMessageRequest = new SendMessageBatchRequest()
                        .withQueueUrl(queue)
                        .withEntries(entries);

                SendMessageBatchResult resultFuture = sqsClient.sendMessageBatch(sendMessageRequest);

                resultFuture
                        .getSuccessful()
                        .stream()
                        .forEach(sendMessageBatchResultEntry ->
                                log.debug("Message send to SQS with message id: {}", sendMessageBatchResultEntry.getMessageId()));

            } catch (Exception e) {
                log.error("Error send message batch to SQS, {}", e.getMessage());
            }
        });
    }

    private String toJson(Object message) {
        try {
            MessageEventProducerDto messageDto = MessageEventProducerDto.builder().data(message).build();
            var objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule());
            return objectMapper.writeValueAsString(messageDto);
        } catch (JsonProcessingException ex) {
            return "";
        }
    }
}
