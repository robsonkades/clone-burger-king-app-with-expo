package com.serasaconsumidor.antifraude.score.batch.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StackEventDto {
    private String document;
    private String eventCode;
    private String subscriptionCode;
    private String userId;
    private String serviceOrigin;
    private String userType;
    private String clientOrigin;
    private StackEventDataDto data;
}
