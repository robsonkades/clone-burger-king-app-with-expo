package com.serasaconsumidor.antifraude.score.batch.event;

public class EventType {

    public static final String FREE_SCORE_BATCH = "3170";
}
