package com.serasaconsumidor.antifraude.score.batch.config.security;

import lombok.RequiredArgsConstructor;

import javax.persistence.AttributeConverter;
import javax.persistence.Convert;

@RequiredArgsConstructor
@Convert
public class StringEncryptConverter implements AttributeConverter<String, String> {

    private final CryptoSymmetric cryptoSymmetric;

    @Override
    public String convertToDatabaseColumn(String s) {
        return cryptoSymmetric.encrypt(s);
    }

    @Override
    public String convertToEntityAttribute(String s) {
        return cryptoSymmetric.decrypt(s);
    }
}

