package com.serasaconsumidor.antifraude.score.batch.config.mapper;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.serasaconsumidor.antifraude.score.batch.config.security.CryptoSymmetric;
import com.serasaconsumidor.antifraude.score.batch.domain.SubscriptionFree;

@Component
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@AllArgsConstructor
public class SubscriptionFreeRowMapper implements RowMapper<SubscriptionFree> {

    CryptoSymmetric cryptoSymmetric;

    @Override
    public SubscriptionFree mapRow(ResultSet resultSet, int i) throws SQLException {
        SubscriptionFree subscriptionFree = new SubscriptionFree();
        subscriptionFree.setId(resultSet.getLong("id"));
        subscriptionFree.setUserId(resultSet.getString("user_id"));
        subscriptionFree.setDocument(cryptoSymmetric.decrypt(resultSet.getString("document")));
        return subscriptionFree;
    }
}
