package com.serasaconsumidor.antifraude.score.batch.config.batch;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.support.JobRegistryBeanPostProcessor;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.batch.core.listener.JobExecutionListenerSupport;
import org.springframework.batch.item.database.JdbcPagingItemReader;
import org.springframework.batch.item.database.Order;
import org.springframework.batch.item.database.PagingQueryProvider;
import org.springframework.batch.item.database.builder.JdbcPagingItemReaderBuilder;
import org.springframework.batch.item.database.support.SqlPagingQueryProviderFactoryBean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.SimpleAsyncTaskExecutor;
import org.springframework.core.task.TaskExecutor;
import org.springframework.retry.annotation.Retryable;

import javax.sql.DataSource;

import java.util.HashMap;
import java.util.Map;

import com.serasaconsumidor.antifraude.score.batch.config.mapper.SubscriptionFreeRowMapper;
import com.serasaconsumidor.antifraude.score.batch.domain.SubscriptionFree;
import com.serasaconsumidor.antifraude.score.batch.listener.ScoreMonitorFreeReadListener;
import com.serasaconsumidor.antifraude.score.batch.write.ScoreMonitorFreeWriter;

@Slf4j
@RequiredArgsConstructor
@Configuration
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ScoreMonitorFreeBatch {

    JobBuilderFactory jobBuilderFactory;
    StepBuilderFactory stepBuilderFactory;
    ScoreMonitorFreeWriter scoreMonitorFreeWriter;
    SubscriptionFreeRowMapper subscriptionFreeRowMapper;
    ScoreMonitorFreeReadListener scoreMonitorFreeReadListener;

    @Qualifier("slaveDataSource")
    DataSource dataSource;

    @Qualifier("scoreMonitorFreeJobListener")
    JobExecutionListenerSupport jobExecutionListenerSupport;

    static int chunkSize = 100;

    @Bean
    public JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor(JobRegistry jobRegistry) {
        JobRegistryBeanPostProcessor jobRegistryBeanPostProcessor = new JobRegistryBeanPostProcessor();
        jobRegistryBeanPostProcessor.setJobRegistry(jobRegistry);
        return jobRegistryBeanPostProcessor;
    }

    @Bean
    public Job scoreMonitorFreeJob() throws Exception {
        return jobBuilderFactory.get("scoreMonitorFreeJob")
                .incrementer(new RunIdIncrementer())
                .listener(jobExecutionListenerSupport)
                .flow(scoreMonitorFreeStep())
                .end()
                .build();
    }

    @Bean
    public Step scoreMonitorFreeStep() throws Exception {
        return stepBuilderFactory.get("scoreMonitorFreeStep")
                .<SubscriptionFree, SubscriptionFree>chunk(chunkSize)
                .reader(freeSubscriptionsReaderPagination())
                .listener(scoreMonitorFreeReadListener)
                .writer(scoreMonitorFreeWriter)
                .faultTolerant()
                .retryLimit(20)
                .retry(Exception.class)
                .allowStartIfComplete(true)
                .taskExecutor(asyncTaskExecutor())
                .build();
    }

    public TaskExecutor asyncTaskExecutor() {
        SimpleAsyncTaskExecutor taskExecutor = new SimpleAsyncTaskExecutor();
        taskExecutor.setConcurrencyLimit(3);
        taskExecutor.setThreadNamePrefix("score-batch");
        return taskExecutor;
    }

    @Bean
    @Retryable(include = { Exception.class }, maxAttempts = 20)
    public JdbcPagingItemReader<SubscriptionFree> freeSubscriptionsReaderPagination() throws Exception {
        Map<String, Object> parameterValues = new HashMap<>();
        parameterValues.put("activated", true);
        return new JdbcPagingItemReaderBuilder<SubscriptionFree>()
                .pageSize(chunkSize)
                .fetchSize(chunkSize)
                .dataSource(dataSource)
                .rowMapper(subscriptionFreeRowMapper)
                .saveState(false)
                .queryProvider(createQueryProvider())
                .parameterValues(parameterValues)
                .name("freeSubscriptionsItemReader")
                .build();
    }

    @Bean
    public PagingQueryProvider createQueryProvider() throws Exception {
        SqlPagingQueryProviderFactoryBean queryProvider = new SqlPagingQueryProviderFactoryBean();
        queryProvider.setDataSource(dataSource);
        queryProvider.setSelectClause("id, user_id, document");
        queryProvider.setFromClause("from subscription.ecs_antifraude_subscription_free");
        queryProvider.setWhereClause("where activated = :activated");
        Map<String, Order> sortKeys = new HashMap<>(1);
        sortKeys.put("id", Order.ASCENDING);
        queryProvider.setSortKeys(sortKeys);
        return queryProvider.getObject();
    }
}
