package com.serasaconsumidor.antifraude.score.batch.event;

import lombok.experimental.UtilityClass;

@UtilityClass
public class FilterType {
    public static final String STACK_EVENTS_SNS_FILTER = "generate-event";
}
