package com.serasaconsumidor.antifraude.score.batch.service;

public interface DeleteTaskService {
    void execute();
}
