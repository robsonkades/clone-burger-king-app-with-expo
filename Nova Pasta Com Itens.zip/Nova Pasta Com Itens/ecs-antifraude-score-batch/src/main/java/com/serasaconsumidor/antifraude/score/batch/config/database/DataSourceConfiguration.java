package com.serasaconsumidor.antifraude.score.batch.config.database;

import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

import com.zaxxer.hikari.HikariDataSource;

import java.util.HashMap;
import java.util.Map;

import com.serasaconsumidor.antifraude.score.batch.config.context.DatabaseEnvironment;

@Configuration
@FieldDefaults(level = AccessLevel.PRIVATE)
public class DataSourceConfiguration {

    @Value("${jdbc.master.url}")
    String masterUrl;

    @Value("${jdbc.master.username}")
    String masterUsername;

    @Value("${jdbc.master.password}")
    String masterPassword;

    @Value("${jdbc.slave.url}")
    String slaveUrl;

    @Value("${jdbc.slave.username}")
    String slaveUsername;

    @Value("${jdbc.slave.password}")
    String slavePassword;

    @Bean
    public DataSource dataSource(){
        MasterSlaveRoutingDataSource masterSlaveRoutingDataSource = new MasterSlaveRoutingDataSource();
        Map<Object, Object> targetDataSources = new HashMap<>();
        targetDataSources.put(DatabaseEnvironment.UPDATABLE, masterDataSource());
        targetDataSources.put(DatabaseEnvironment.READONLY, slaveDataSource());
        masterSlaveRoutingDataSource.setTargetDataSources(targetDataSources);
        masterSlaveRoutingDataSource.setDefaultTargetDataSource(masterDataSource());
        return masterSlaveRoutingDataSource;
    }

    @Bean("slaveDataSource")
    public DataSource slaveDataSource() {
        HikariDataSource hikariDataSource = new HikariDataSource();
        hikariDataSource.setPoolName("subscription-slave-batch");
        hikariDataSource.setAutoCommit(false);
        hikariDataSource.setJdbcUrl(slaveUrl);
        hikariDataSource.setAutoCommit(false);
        hikariDataSource.setMinimumIdle(3);
        hikariDataSource.setMaxLifetime(1800000);
        hikariDataSource.setMaximumPoolSize(50);
        hikariDataSource.setConnectionTimeout(20000);
        hikariDataSource.setIdleTimeout(600000);
        hikariDataSource.setUsername(slaveUsername);
        hikariDataSource.setPassword(slavePassword);
        return hikariDataSource;
    }

    public DataSource masterDataSource() {
        HikariDataSource hikariDataSource = new HikariDataSource();
        hikariDataSource.setJdbcUrl(masterUrl);
        hikariDataSource.setPoolName("subscription-master-batch");
        hikariDataSource.setAutoCommit(false);
        hikariDataSource.setMinimumIdle(3);
        hikariDataSource.setMaxLifetime(1800000);
        hikariDataSource.setMaximumPoolSize(50);
        hikariDataSource.setConnectionTimeout(20000);
        hikariDataSource.setIdleTimeout(600000);
        hikariDataSource.setUsername(masterUsername);
        hikariDataSource.setPassword(masterPassword);
        return hikariDataSource;
    }
}
