package com.serasaconsumidor.antifraude.score.batch.config.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

public class BaseClient {

    @Autowired
    protected RestTemplate restTemplate;
}
