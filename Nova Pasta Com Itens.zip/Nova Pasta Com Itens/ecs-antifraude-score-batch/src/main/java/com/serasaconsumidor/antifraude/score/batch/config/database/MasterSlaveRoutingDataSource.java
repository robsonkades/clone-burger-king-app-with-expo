package com.serasaconsumidor.antifraude.score.batch.config.database;

import org.springframework.jdbc.datasource.lookup.AbstractRoutingDataSource;

import com.serasaconsumidor.antifraude.score.batch.config.context.DatabaseContextHolder;

public class MasterSlaveRoutingDataSource extends AbstractRoutingDataSource {

    @Override
    protected Object determineCurrentLookupKey() {
        return DatabaseContextHolder.getEnvironment();
    }

}
