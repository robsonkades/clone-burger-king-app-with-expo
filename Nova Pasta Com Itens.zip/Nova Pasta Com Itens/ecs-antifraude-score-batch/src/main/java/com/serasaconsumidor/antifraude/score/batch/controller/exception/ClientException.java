package com.serasaconsumidor.antifraude.score.batch.controller.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class ClientException extends ResponseStatusException {

    public ClientException(HttpStatus statusCode, String error) {
        super(statusCode, error);
    }
}
