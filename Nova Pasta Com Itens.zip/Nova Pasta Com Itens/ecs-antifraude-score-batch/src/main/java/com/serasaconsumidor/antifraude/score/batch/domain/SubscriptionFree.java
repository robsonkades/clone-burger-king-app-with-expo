package com.serasaconsumidor.antifraude.score.batch.domain;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.FieldDefaults;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "ecs_antifraude_subscription_free")
@Table(schema = "subscription")
@FieldDefaults(level = AccessLevel.PRIVATE)
@Getter
@Setter
public class SubscriptionFree {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;

    @Column(name = "document")
    String document;

    @Column(name = "user_id")
    String userId;

    @Override
    public String toString() {
        return "SubscriptionFree{" +
                "id='" + id + '\'' +
                ", document='" + document + '\'' +
                ", userId='" + userId + '\'' +
                '}';
    }
}
