package com.serasaconsumidor.antifraude.score.batch.listener;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.Map;

import com.serasaconsumidor.antifraude.score.batch.dto.RequestScoreMessageDto;
import com.serasaconsumidor.antifraude.score.batch.service.CreateTaskService;

@Component
@Slf4j
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class SqsMessageListener {

    Map<String, CreateTaskService> createTaskServiceMap;

    //@JmsListener(destination = "${aws.sqs.queue.scoreLoaderFree}")
    public void messageConsumer(@Payload String message, @Headers Map<String, Object> headers) {
        try {
            var scoreMessage = RequestScoreMessageDto.fromJson(message);
            log.info("Receiving load score event: {}", scoreMessage.getScore());
            CreateTaskService invokeJobService = createTaskServiceMap.get("CREATE_SCORE_MONITOR_FREE");
            invokeJobService.execute();
        } catch (Exception ex) {
            log.error("Error receiver score process", ex.getMessage());
            throw ex;
        }
    }
}
