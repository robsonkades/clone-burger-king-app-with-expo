package com.serasaconsumidor.antifraude.score.batch.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import java.io.IOException;
import java.time.OffsetDateTime;

public class CustomOffsetDateTimeDeserializer extends JsonDeserializer<OffsetDateTime> {

    public CustomOffsetDateTimeDeserializer() {}

    @Override
    public OffsetDateTime deserialize(JsonParser parser, DeserializationContext context) throws IOException, JsonProcessingException {
        return OffsetDateTime.parse(parser.getText());
    }
}

