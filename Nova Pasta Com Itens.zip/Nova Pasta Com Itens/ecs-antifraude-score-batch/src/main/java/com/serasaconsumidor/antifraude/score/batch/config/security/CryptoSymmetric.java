package com.serasaconsumidor.antifraude.score.batch.config.security;

public interface CryptoSymmetric {
    String encrypt(String string);
    String decrypt(String string);
}
