package com.serasaconsumidor.antifraude.score.batch.config.aws.sns;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.amazonaws.regions.Regions;
import com.amazonaws.services.sns.AmazonSNSAsync;
import com.amazonaws.services.sns.AmazonSNSAsyncClientBuilder;

@Configuration
public class SnsConfiguration {

    @Bean
    @Primary
    public AmazonSNSAsync ssnClient() {
        return AmazonSNSAsyncClientBuilder.standard()
                .withRegion(Regions.US_EAST_1)
                .build();
    }
}

