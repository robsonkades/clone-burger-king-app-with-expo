package com.serasaconsumidor.antifraude.score.batch.service;

public interface CreateTaskService {
    void execute();
}
