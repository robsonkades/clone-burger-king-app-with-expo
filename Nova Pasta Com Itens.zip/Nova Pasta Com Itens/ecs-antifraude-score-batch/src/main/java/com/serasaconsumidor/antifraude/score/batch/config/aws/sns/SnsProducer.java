package com.serasaconsumidor.antifraude.score.batch.config.aws.sns;

public interface SnsProducer {
    void sendMessage(final Object message, final String topicArn, final String eventType);
}
