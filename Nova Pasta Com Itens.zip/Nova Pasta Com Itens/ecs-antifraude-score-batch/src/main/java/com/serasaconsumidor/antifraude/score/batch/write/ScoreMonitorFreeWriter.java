package com.serasaconsumidor.antifraude.score.batch.write;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.item.ItemWriter;
import org.springframework.stereotype.Component;

import java.util.List;

import com.serasaconsumidor.antifraude.score.batch.config.aws.sqs.QueueProperties;
import com.serasaconsumidor.antifraude.score.batch.config.aws.sqs.SqsProducer;
import com.serasaconsumidor.antifraude.score.batch.domain.SubscriptionFree;

@Component
@Slf4j
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
@AllArgsConstructor
public class ScoreMonitorFreeWriter implements ItemWriter<SubscriptionFree> {

    SqsProducer sqsProducer;
    QueueProperties queueProperties;

    @Override
    public void write(List<? extends SubscriptionFree> list) {
        sqsProducer.sendMessageBatch(list, queueProperties.getScoreMonitorFree());
    }
}
