package com.serasaconsumidor.antifraude.score.batch.listener;

import lombok.extern.slf4j.Slf4j;
import org.springframework.batch.core.ItemReadListener;
import org.springframework.stereotype.Component;

import com.serasaconsumidor.antifraude.score.batch.domain.SubscriptionFree;

@Component("ScoreMonitorFreeReadListener")
@Slf4j
public class ScoreMonitorFreeReadListener implements ItemReadListener<SubscriptionFree> {

    @Override
    public void beforeRead() {
    }

    @Override
    public void afterRead(SubscriptionFree subscriptionFree) {
    }

    @Override
    public void onReadError(Exception e){
    }
}
