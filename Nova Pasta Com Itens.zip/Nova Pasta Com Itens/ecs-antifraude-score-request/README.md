# Score request


### Environments
|  Name | Required  | Default  |
|---|---|---|
|  ECS_ENVIRONMENT  | x |  |
|  SERVER_PORT  |  | 80  |
|  CONTEXT_PATH  |  | /af/score/request  |
|  AWS_REGION  | x |   |
|  LOAD_SCORE_FINISHED_QUEUE | x  |   |
|  SCORE_URL | x  |   |
|  SUBSCRIPTION_CONSUMER_URL |  x |   |
|  REQUEST_SCORE_QUEUE | x  |   |
|  CRYPT_IV | x  |   |
|  CRYPT_KEY |  x |   |
|  STACK_EVENTS_SNS_TOPIC_ARN |  x |   |
|  STACK_EVENTS_SNS_TOPIC_ARN |  x |   |
|  UPDATED_SCORE_QUEUE | x | |
|  SQS_CONCURRENCY |  | 1-2 |
|  NUMBER_MESSAGES_OF_PREFETCH |  | 5 |
| MAX_MESSAGES_PER_TASK |  | 10 |