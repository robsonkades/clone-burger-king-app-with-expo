# 1.0.0
[17/03/2021]

## Quebras de compatibilidade

## Novas funcionalidades
* [SPB-797](https://serasaexperian.atlassian.net/browse/SPB-797) - Criado serviço para gerenciar as solicitações de score dos assinantes do Premium.

## Melhorias

## Correções

## Alterações de banco de dados

## Alterações de dependências
* `score-number`: 0.0.0 > 0.0.0
* `consumer-sub`: 0.0.0 > 0.0.0
