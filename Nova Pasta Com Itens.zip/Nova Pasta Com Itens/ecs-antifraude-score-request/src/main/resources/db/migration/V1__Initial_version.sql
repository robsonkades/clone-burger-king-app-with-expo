CREATE SCHEMA IF NOT EXISTS score_request;

CREATE TABLE score_request.carousel_total_view
(
    id                   UUID PRIMARY KEY,
    user_id              UUID NOT NULL UNIQUE,
    preview_date         TIMESTAMP NOT NULL
);
