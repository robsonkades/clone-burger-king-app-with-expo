package com.serasaconsumidor.antifraude.score.request.config.http.clients;

public interface ScoreBatch {

    void runBatch(String job);
}
