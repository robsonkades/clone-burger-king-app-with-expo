package com.serasaconsumidor.antifraude.score.request.utils;

import lombok.experimental.UtilityClass;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

@UtilityClass
public class UriUtils {

    public static String pathObfuscator(String path) {
        String REGEX_CPF_CNPJ = "(\\d{14})|(\\d{11})";

        Matcher matcher = Pattern.compile(REGEX_CPF_CNPJ).matcher(path);
        StringBuffer sb = new StringBuffer();

        while (matcher.find()) {
            if (matcher.group().length() == 11) {
                matcher.appendReplacement(sb, "******".concat(matcher.group().substring(6, 11)));
            }
            if (matcher.group().length() == 14) {
                matcher.appendReplacement(sb, "********".concat(matcher.group().substring(8, 14)));
            }
        }

        matcher.appendTail(sb);

        return sb.toString();
    }

}