package com.serasaconsumidor.antifraude.score.request.services;

public interface ProcessScoreService {
    void execute();
}
