package com.serasaconsumidor.antifraude.score.request.controllers;

import com.serasaconsumidor.antifraude.score.request.dtos.RequestViewCarouselDto;
import com.serasaconsumidor.antifraude.score.request.dtos.ViewCarouselDto;
import com.serasaconsumidor.antifraude.score.request.services.CreateViewCarouselService;
import com.serasaconsumidor.antifraude.score.request.services.GetViewCarouselService;
import lombok.AllArgsConstructor;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

@RestController
@RequestMapping("/v1/score")
@AllArgsConstructor
public class ScoreUserController {

    private final GetViewCarouselService getViewCarouselService;
    private final CreateViewCarouselService createViewCarouselService;


    @CrossOrigin(origins = "*")
    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ViewCarouselDto> read(@RequestBody @Valid RequestViewCarouselDto request) {
        return ResponseEntity.ok(getViewCarouselService.execute(request));
    }

    @CrossOrigin(origins = "*")
    @PostMapping(path = "/view", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> create(@RequestBody @Valid RequestViewCarouselDto request) {
        return ResponseEntity.ok(createViewCarouselService.execute(request));
    }

}
