package com.serasaconsumidor.antifraude.score.request.repository;

import com.serasaconsumidor.antifraude.score.request.domain.CarouselTotalViewEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.UUID;

@Repository
public interface CarouselTotalViewRepository extends JpaRepository<CarouselTotalViewEntity, UUID> {

    boolean existsByUserId(UUID userId);
}
