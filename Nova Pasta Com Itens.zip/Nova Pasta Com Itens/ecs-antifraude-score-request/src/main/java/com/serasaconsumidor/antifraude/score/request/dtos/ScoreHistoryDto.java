package com.serasaconsumidor.antifraude.score.request.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ScoreHistoryDto {
    private long score;
    private long variance;
    private String date;
    private String model;
    private ScoreNumberMessageDto message;
}