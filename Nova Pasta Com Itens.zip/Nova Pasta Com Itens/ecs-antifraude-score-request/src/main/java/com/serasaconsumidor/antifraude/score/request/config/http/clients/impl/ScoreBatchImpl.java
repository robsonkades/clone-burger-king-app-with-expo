package com.serasaconsumidor.antifraude.score.request.config.http.clients.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;

import javax.validation.constraints.Null;

import com.serasaconsumidor.antifraude.score.request.config.http.HttpClient;
import com.serasaconsumidor.antifraude.score.request.config.http.clients.ScoreBatch;

@Component
@Slf4j
public class ScoreBatchImpl extends HttpClient implements ScoreBatch {

    private static final String SCORE_BATCH_URI = "/af/score/batch/v1/tasks/";

    @Override
    public void runBatch(String job) {
        try {
            final String url = clientUrl.getScoreBatchUrl() + SCORE_BATCH_URI + job;
            final HttpEntity<Null> requestEntity = new HttpEntity<>(null, null);
            restTemplate.exchange(
                    url,
                    HttpMethod.POST,
                    requestEntity,
                    new ParameterizedTypeReference<>() {
                    }
            );
        } catch (Exception e) {
            log.error("There was an error when starting score batch. Client returned {}", e.getMessage());
        }
    }
}
