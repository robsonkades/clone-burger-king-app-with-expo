package com.serasaconsumidor.antifraude.score.request.listeners;

import com.serasaconsumidor.antifraude.score.request.dtos.RequestScoreMessageDto;

public interface RequestProcessScoreListener {
    void messageConsumer(RequestScoreMessageDto event);
}
