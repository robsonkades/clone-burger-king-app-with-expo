package com.serasaconsumidor.antifraude.score.request.listeners.impl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

import com.serasaconsumidor.antifraude.score.request.config.redis.RedisManager;
import com.serasaconsumidor.antifraude.score.request.constants.Constants;
import com.serasaconsumidor.antifraude.score.request.dtos.ProcessScoreModelDto;
import com.serasaconsumidor.antifraude.score.request.dtos.RequestScoreMessageDto;
import com.serasaconsumidor.antifraude.score.request.listeners.RequestProcessScoreListener;

@Slf4j
@AllArgsConstructor
@Component
public class RequestProcessScoreListenerImpl implements RequestProcessScoreListener {

    RedisManager redisManager;
    private static final int CACHE_EXPIRE = 720; // 12 horas

    @Override
    @Async
    @EventListener({ RequestScoreMessageDto.class })
    public void messageConsumer(RequestScoreMessageDto event) {
        var processScoreModelDtoOptional = redisManager.findValue(Constants.SCORE_BATCH_KEY, ProcessScoreModelDto.class);
        if (processScoreModelDtoOptional.isPresent()) {
            var processScoreModelDto = processScoreModelDtoOptional.get();
            redisManager.setValue(Constants.SCORE_BATCH_KEY, ProcessScoreModelDto
                    .builder()
                    .lastUpdate(LocalDateTime.now())
                    .model(event.getScore())
                    .size(processScoreModelDto.getSize() + 1)
                    .build(), CACHE_EXPIRE);
        } else {
            redisManager.setValue(Constants.SCORE_BATCH_KEY, ProcessScoreModelDto
                    .builder()
                    .lastUpdate(LocalDateTime.now())
                    .model(event.getScore())
                    .size(1)
                    .build(), CACHE_EXPIRE);
        }
    }
}
