package com.serasaconsumidor.antifraude.score.request.services.impl;

import com.serasaconsumidor.antifraude.score.request.config.http.clients.Score;
import com.serasaconsumidor.antifraude.score.request.dtos.RequestScoreNumberDto;
import com.serasaconsumidor.antifraude.score.request.dtos.RequestViewCarouselDto;
import com.serasaconsumidor.antifraude.score.request.dtos.ScoreHistoryDto;
import com.serasaconsumidor.antifraude.score.request.dtos.ViewCarouselDto;
import com.serasaconsumidor.antifraude.score.request.repository.CarouselTotalViewRepository;
import com.serasaconsumidor.antifraude.score.request.services.GetViewCarouselService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@AllArgsConstructor
public class GetViewCarouselServiceImpl implements GetViewCarouselService {

    private final CarouselTotalViewRepository repository;
    private final Score score;

    @Override
    @Transactional(readOnly = true)
    public ViewCarouselDto execute(RequestViewCarouselDto request) {
        boolean exists = repository.existsByUserId(request.getUserId());
        if (exists) {
            return ViewCarouselDto.builder().showCarousel(false).build();
        }

        RequestScoreNumberDto requestScore = RequestScoreNumberDto.builder()
                .document(request.getDocument())
                .userId(request.getUserId())
                .build();
        List<ScoreHistoryDto> listScoreHistory = score.listHistory(requestScore).get();

        long count = listScoreHistory.stream().filter(f -> f.getModel() != null && f.getModel().equalsIgnoreCase("hspn_score")).count();
        return ViewCarouselDto.builder().showCarousel(count != 0 && count != 6).build();
    }
}
