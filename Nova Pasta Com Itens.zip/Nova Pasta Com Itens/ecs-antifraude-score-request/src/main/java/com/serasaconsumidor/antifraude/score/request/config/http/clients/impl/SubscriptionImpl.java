package com.serasaconsumidor.antifraude.score.request.config.http.clients.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import javax.validation.constraints.Null;

import java.util.Objects;
import java.util.Optional;
import java.util.UUID;

import com.serasaconsumidor.antifraude.score.request.config.http.HttpClient;
import com.serasaconsumidor.antifraude.score.request.config.http.clients.Subscription;
import com.serasaconsumidor.antifraude.score.request.dtos.BaseResponseListDto;
import com.serasaconsumidor.antifraude.score.request.dtos.SubscriptionDto;

@Component
@Slf4j
public class SubscriptionImpl extends HttpClient implements Subscription {

    private static final String SUBSCRIPTION_URI = "/af/consumer/subscription/v3/subscriptions/";

    @Override
    public Optional<BaseResponseListDto<SubscriptionDto>> listAll(int size, int page) {
        try {
            final String url = clientUrl.getSubscriptionUrl() + SUBSCRIPTION_URI + "?size=" + size + "&page=" + page;
            final HttpEntity<Null> requestEntity = new HttpEntity<>(null, null);

            ResponseEntity<BaseResponseListDto<SubscriptionDto>> responseEntity =
                    restTemplate.exchange(
                            url,
                            HttpMethod.GET,
                            requestEntity,
                            new ParameterizedTypeReference<>() {
                            }
                    );
            if (!Objects.requireNonNull(responseEntity.getBody()).getData().isEmpty()) {
                return Optional.ofNullable(responseEntity.getBody());
            }

        } catch (Exception e) {
            log.error("There was an error when trying to retrieve subscription information from subscriptions client. Client returned {}", e.getMessage());
        }
        log.warn("Empty subscriptions list");
        return Optional.empty();
    }

    @Override
    public Optional<BaseResponseListDto<SubscriptionDto>> listAllByUserId(UUID userId) {
        try {
            final String url = clientUrl.getSubscriptionUrl() + SUBSCRIPTION_URI + "?userId=" + userId;
            final HttpEntity<Null> requestEntity = new HttpEntity<>(null, null);

            ResponseEntity<BaseResponseListDto<SubscriptionDto>> responseEntity =
                    restTemplate.exchange(
                            url,
                            HttpMethod.GET,
                            requestEntity,
                            new ParameterizedTypeReference<>() {
                            }
                    );
            if (!Objects.requireNonNull(responseEntity.getBody()).getData().isEmpty()) {
                return Optional.ofNullable(responseEntity.getBody());
            }

        } catch (Exception e) {
            log.error("There was an error when trying to retrieve subscription information from subscriptions client. Client returned {}", e.getMessage());
        }
        log.warn("Empty subscriptions list");
        return Optional.empty();
    }

    @Override
    public Optional<BaseResponseListDto<SubscriptionDto>> listBySubscriptionCode(UUID subscriptionCode) {
        try {
            final String url = clientUrl.getSubscriptionUrl() + SUBSCRIPTION_URI + "?subscriptionCode=" + subscriptionCode;
            final HttpEntity<Null> requestEntity = new HttpEntity<>(null, null);

            ResponseEntity<BaseResponseListDto<SubscriptionDto>> responseEntity =
                    restTemplate.exchange(
                            url,
                            HttpMethod.GET,
                            requestEntity,
                            new ParameterizedTypeReference<>() {
                            }
                    );
            if (!Objects.requireNonNull(responseEntity.getBody()).getData().isEmpty()) {
                return Optional.ofNullable(responseEntity.getBody());
            }

        } catch (Exception e) {
            log.error("There was an error when trying to retrieve subscription information from subscriptions client. Client returned {}", e.getMessage());
        }
        log.warn("Empty subscriptions list");
        return Optional.empty();
    }
}
