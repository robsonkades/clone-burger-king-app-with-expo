package com.serasaconsumidor.antifraude.score.request.services;

import com.serasaconsumidor.antifraude.score.request.dtos.ProcessScoreMessageDto;

public interface ProcessScorePagedSubscriptions {

    void execute(ProcessScoreMessageDto processScoreMessageDto);
}
