package com.serasaconsumidor.antifraude.score.request.config.redis;

import java.util.Optional;

public interface RedisManager {
    Boolean setValue(String key, Object value, long expire);
    Boolean setValueEncrypt(String key, Object value, long expire);
    Boolean hasKey(String key);
    <T> Optional<T> findValue(String key, Class<T> classToMap);
    <T> Optional<T> findValueDecrypt(String key, Class<T> classToMap);
    Boolean delete(String key);
    Boolean isAvailable();
}

