package com.serasaconsumidor.antifraude.score.request.config.aws.sqs;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Setter
@Getter
@Component
@ConfigurationProperties(prefix = "aws.sqs")
public class SqsProperties {
    private String region;
    private String concurrency;
    private int numberMessagesOfPrefetch;
    private Integer maxMessagesPerTask;
    private String loadScoreQueue;
    private String requestScoreQueue;
    private String updatedRequestQueue;
    private String scoreProcessQueue;
    private int delay;
}
