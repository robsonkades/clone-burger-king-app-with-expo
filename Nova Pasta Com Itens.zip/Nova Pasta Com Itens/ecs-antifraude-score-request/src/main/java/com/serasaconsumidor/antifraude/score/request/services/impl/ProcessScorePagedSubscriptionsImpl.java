package com.serasaconsumidor.antifraude.score.request.services.impl;

import lombok.AllArgsConstructor;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.List;

import com.serasaconsumidor.antifraude.score.request.config.aws.sqs.SqsProducer;
import com.serasaconsumidor.antifraude.score.request.config.aws.sqs.SqsProperties;
import com.serasaconsumidor.antifraude.score.request.dtos.ProcessScoreMessageDto;
import com.serasaconsumidor.antifraude.score.request.dtos.SubscriptionDto;
import com.serasaconsumidor.antifraude.score.request.services.ListSubscriptionsService;
import com.serasaconsumidor.antifraude.score.request.services.ProcessScorePagedSubscriptions;

@Service
@AllArgsConstructor
public class ProcessScorePagedSubscriptionsImpl implements ProcessScorePagedSubscriptions {

    private final ListSubscriptionsService listSubscriptionsService;
    private final SqsProducer sqsProducer;
    private final SqsProperties sqsProperties;

    @Override
    public void execute(ProcessScoreMessageDto processScoreMessageDto) {

        var processScoreData = processScoreMessageDto.getData();
        var subscriptionsPage = listSubscriptionsService.execute(processScoreData.getSize(), processScoreData.getPage());

        subscriptionsPage.ifPresent((pageSubscriptions) -> {
            if (CollectionUtils.isNotEmpty(pageSubscriptions.getData())) {
                List<SubscriptionDto> subscriptions = pageSubscriptions.getData();
                sqsProducer.sendMessageBatch(subscriptions, sqsProperties.getRequestScoreQueue());
            }
        });
    }
}
