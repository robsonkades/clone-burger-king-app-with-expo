package com.serasaconsumidor.antifraude.score.request.controllers;

import lombok.AllArgsConstructor;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

import com.serasaconsumidor.antifraude.score.request.dtos.RequestScoreMessageDto;

@RestController
@RequestMapping("/v1")
@AllArgsConstructor
public class ProcessScoreController {

    ApplicationEventPublisher eventPublisher;

    @PostMapping(path = "/process", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> create(@RequestBody @Valid RequestScoreMessageDto scoreMessage) {
        eventPublisher.publishEvent(scoreMessage);
        return ResponseEntity.noContent().build();
    }
}
