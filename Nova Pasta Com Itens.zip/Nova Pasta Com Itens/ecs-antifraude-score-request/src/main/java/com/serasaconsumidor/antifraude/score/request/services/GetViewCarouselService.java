package com.serasaconsumidor.antifraude.score.request.services;

import com.serasaconsumidor.antifraude.score.request.dtos.RequestViewCarouselDto;
import com.serasaconsumidor.antifraude.score.request.dtos.ViewCarouselDto;

public interface GetViewCarouselService {

    ViewCarouselDto execute(RequestViewCarouselDto request);
}
