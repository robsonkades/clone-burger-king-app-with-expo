package com.serasaconsumidor.antifraude.score.request.config.http;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Getter
@Setter
@Component
@ConfigurationProperties(prefix = "client.endpoints")
public class ClientUrl {
    private String scoreNumber;
    private String scoreHistory;
    private String subscriptionUrl;
    private String scoreBatchUrl;
}