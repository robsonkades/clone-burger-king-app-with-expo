package com.serasaconsumidor.antifraude.score.request.services.impl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Optional;

import com.serasaconsumidor.antifraude.score.request.config.ServerProperties;
import com.serasaconsumidor.antifraude.score.request.config.aws.sns.SnsProducer;
import com.serasaconsumidor.antifraude.score.request.config.aws.sns.SnsProperties;
import com.serasaconsumidor.antifraude.score.request.config.aws.sqs.SqsProducer;
import com.serasaconsumidor.antifraude.score.request.config.aws.sqs.SqsProperties;
import com.serasaconsumidor.antifraude.score.request.constants.Events;
import com.serasaconsumidor.antifraude.score.request.dtos.BaseResponseListDto;
import com.serasaconsumidor.antifraude.score.request.dtos.ProcessScoreDataDto;
import com.serasaconsumidor.antifraude.score.request.dtos.StackEventDto;
import com.serasaconsumidor.antifraude.score.request.dtos.SubscriptionDto;
import com.serasaconsumidor.antifraude.score.request.services.ListSubscriptionsService;
import com.serasaconsumidor.antifraude.score.request.services.ProcessScoreService;

import static com.serasaconsumidor.antifraude.score.request.constants.Constants.EVENT_PROCESS_SCORE_MONITORING;
import static com.serasaconsumidor.antifraude.score.request.constants.Constants.STACK_EVENTS_SNS_FILTER;

@Slf4j
@Service
@AllArgsConstructor
public class ProcessScoreServiceImpl implements ProcessScoreService {

    private final ListSubscriptionsService listSubscriptionsService;
    private final SqsProducer sqsProducer;
    private final SqsProperties sqsProperties;
    private final ServerProperties serverProperties;
    private final SnsProducer snsProducer;
    private final SnsProperties snsProperties;

    @Override
    @Async
    public void execute() {
        log.info("List all subscriptions");
        var payload = StackEventDto
                .builder()
                .clientOrigin(serverProperties.getClient())
                .serviceOrigin(serverProperties.getName())
                .eventCode(Events.SCORE_UPDATED)
                .build();
        try {
            snsProducer.sendMessage(payload, snsProperties.getTopicArnStackEvents(), STACK_EVENTS_SNS_FILTER);
        } catch (Exception ex) {
            log.error("Error sending stackEvent {}", ex.getMessage());
        }

        Optional<BaseResponseListDto<SubscriptionDto>> subscriptionsPage = listSubscriptionsService.execute(100, 0);

        subscriptionsPage.ifPresent((pageSubscriptions) -> {
            var totalPages = pageSubscriptions.getTotalPages();
            var pageSize = pageSubscriptions.getPageSize();
            processToAllSubscriptions(0, pageSize, totalPages);
        });
    }

    private void processToAllSubscriptions(int currentPage, int pageSize, int totalPages) {
        log.info("Subscription: currentPage {}, pageSize {}, totalPages {}", currentPage, pageSize, totalPages);
        ProcessScoreDataDto scoreMessageDto = ProcessScoreDataDto
                .builder()
                .page(currentPage)
                .size(pageSize)
                .event(EVENT_PROCESS_SCORE_MONITORING)
                .build();

        sqsProducer.sendMessage(scoreMessageDto, sqsProperties.getScoreProcessQueue());
        if (currentPage <= totalPages) {
            processToAllSubscriptions(currentPage + 1, pageSize, totalPages);
        }
    }
}
