package com.serasaconsumidor.antifraude.score.request.config.http.clients.impl;

import com.serasaconsumidor.antifraude.score.request.config.http.HttpClient;
import com.serasaconsumidor.antifraude.score.request.config.http.clients.Score;
import com.serasaconsumidor.antifraude.score.request.dtos.RequestScoreNumberDto;
import com.serasaconsumidor.antifraude.score.request.dtos.ScoreHistoryDto;
import com.serasaconsumidor.antifraude.score.request.dtos.ScoreNumberDto;
import com.serasaconsumidor.antifraude.score.request.exception.RestTemplateException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Component
@Slf4j
public class ScoreImpl extends HttpClient implements Score {

    private static final String PREMIUM_BATCH = "premium-batch";
    private static final String NUMBER_URN = "/score/number/v1/internal/explainer";
    private static final String HISTORY_URN = "/score/history/v1/internal";

    @Override
    public Optional<ScoreNumberDto> getScore(RequestScoreNumberDto requestScoreDto) {
        try {
            final HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.add("X-Score-Client-Id", PREMIUM_BATCH);

            final HttpEntity<Object> requestEntity = new HttpEntity<>(requestScoreDto, httpHeaders);
            final String url = clientUrl.getScoreNumber() + NUMBER_URN;

            ResponseEntity<ScoreNumberDto> responseEntity =
                    restTemplate.exchange(
                            url,
                            HttpMethod.POST,
                            requestEntity,
                            ScoreNumberDto.class
                    );

            if (responseEntity.getBody() == null) {
                log.error("the score response body returned null for user id {}", requestScoreDto.getUserId());
                return Optional.empty();
            }

            return Optional.ofNullable(responseEntity.getBody());
        } catch (RestTemplateException e) {
            if (e.getStatusCode().equals(HttpStatus.FAILED_DEPENDENCY)) {
                log.warn("There was an error when trying to retrieve score information from user {}. Client returned {}", requestScoreDto.getUserId(), e.getMessage());
                return Optional.empty();
            }
            if (e.getStatusCode().equals(HttpStatus.PRECONDITION_FAILED)) {
                log.warn("There was an error when trying to retrieve score information from user {}. Client returned {}", requestScoreDto.getUserId(), e.getMessage());
                return Optional.empty();
            }
            log.error("There was an error when trying to retrieve score information from user {}. Client returned {}", requestScoreDto.getUserId(), e.getMessage());
            return Optional.empty();
        } catch (Exception e) {
            log.error("There was an error when trying to retrieve score information from user {}. Client returned {}", requestScoreDto.getUserId(), e.getMessage());
            throw new RuntimeException(e);
        }
    }

    public Optional<List<ScoreHistoryDto>> listHistory(RequestScoreNumberDto requestScoreDto) {
        try {
            final HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.add("X-Score-Client-Id", PREMIUM_BATCH);

            final HttpEntity<Object> requestEntity = new HttpEntity<>(requestScoreDto, httpHeaders);
            final String url = clientUrl.getScoreHistory() + HISTORY_URN;

            log.info("url: {}, user: {}, document: {}", url, requestScoreDto.getUserId(), requestScoreDto.getDocument());

            ResponseEntity<ScoreHistoryDto[]> responseEntity =
                    restTemplate.exchange(
                            url,
                            HttpMethod.POST,
                            requestEntity,
                            ScoreHistoryDto[].class
                    );

            if (responseEntity.getBody() == null) {
                log.error("the score response body returned null for user id {}", requestScoreDto.getUserId());
                return Optional.of(new ArrayList<>());
            }

            return Optional.of(Arrays.asList(responseEntity.getBody()));
        } catch (RestTemplateException e) {
            log.error("There was an error when trying to retrieve score information from user {}. Client returned {}", requestScoreDto.getUserId(), e.getMessage());
            return Optional.of(new ArrayList<>());
        }
    }
}
