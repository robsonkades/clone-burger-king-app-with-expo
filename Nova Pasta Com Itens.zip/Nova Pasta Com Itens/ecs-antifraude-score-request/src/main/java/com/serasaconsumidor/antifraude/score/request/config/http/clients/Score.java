package com.serasaconsumidor.antifraude.score.request.config.http.clients;

import java.util.List;
import java.util.Optional;

import com.serasaconsumidor.antifraude.score.request.dtos.RequestScoreNumberDto;
import com.serasaconsumidor.antifraude.score.request.dtos.ScoreHistoryDto;
import com.serasaconsumidor.antifraude.score.request.dtos.ScoreNumberDto;

public interface Score {

    Optional<ScoreNumberDto> getScore(RequestScoreNumberDto requestScoreDto);
    Optional<List<ScoreHistoryDto>> listHistory(RequestScoreNumberDto requestScoreDto);
}
