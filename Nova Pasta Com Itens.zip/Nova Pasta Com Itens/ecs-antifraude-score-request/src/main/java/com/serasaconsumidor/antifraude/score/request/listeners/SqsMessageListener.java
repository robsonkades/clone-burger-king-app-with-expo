package com.serasaconsumidor.antifraude.score.request.listeners;

import java.util.Map;

public interface SqsMessageListener {
    void messageConsumer(String message, Map<String, Object> headers);
}
