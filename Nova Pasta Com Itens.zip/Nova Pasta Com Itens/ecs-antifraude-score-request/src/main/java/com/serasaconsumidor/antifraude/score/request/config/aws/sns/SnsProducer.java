package com.serasaconsumidor.antifraude.score.request.config.aws.sns;

public interface SnsProducer {
    void sendMessage(Object message, String topicArn, String eventType);
}
