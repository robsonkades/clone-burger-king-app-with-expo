package com.serasaconsumidor.antifraude.score.request.interceptors;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import java.io.IOException;

import com.serasaconsumidor.antifraude.score.request.utils.UriUtils;

@Slf4j
@RequiredArgsConstructor
@Component
public class RestTemplateInterceptor implements ClientHttpRequestInterceptor {

    @Override
    public ClientHttpResponse intercept(HttpRequest httpRequest, byte[] body, final ClientHttpRequestExecution clientHttpRequestExecution) throws IOException {
        logRequest(httpRequest, body);
        ClientHttpResponse response = clientHttpRequestExecution.execute(httpRequest, body);
        logResponse(response);
        MDC.remove("contextService");
        MDC.remove("contextStatusCode");
        return response;
    }

    private void logRequest(HttpRequest request, byte[] body) {
        MDC.put("contextService", UriUtils.pathObfuscator(request.getURI().getRawPath()));
        log.info("request begin");

    }

    private void logResponse(ClientHttpResponse response) throws IOException {
        MDC.put("contextStatusCode", response.getStatusCode().toString());
        log.info("request end");
    }
}