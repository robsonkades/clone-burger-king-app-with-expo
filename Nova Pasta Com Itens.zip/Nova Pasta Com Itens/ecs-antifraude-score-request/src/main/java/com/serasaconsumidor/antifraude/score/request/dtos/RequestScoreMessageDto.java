package com.serasaconsumidor.antifraude.score.request.dtos;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

import java.time.LocalDate;
import java.time.OffsetDateTime;

import com.serasaconsumidor.antifraude.score.request.exception.MapperReadValueException;
import com.serasaconsumidor.antifraude.score.request.utils.CustomOffsetDateTimeDeserializer;
import com.serasaconsumidor.antifraude.score.request.utils.CustomOffsetDateTimeSerializer;
import com.serasaconsumidor.antifraude.score.request.utils.CustomOffsetLocalDateDeserializer;
import com.serasaconsumidor.antifraude.score.request.utils.CustomOffsetLocalDateSerializer;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestScoreMessageDto {

    @NotNull
    private String score;

    @JsonProperty("updated_at")
    @JsonSerialize(using = CustomOffsetDateTimeSerializer.class)
    @JsonDeserialize(using = CustomOffsetDateTimeDeserializer.class)
    @NotNull
    private OffsetDateTime updatedAt;

    @JsonProperty("dt_t0")
    @JsonSerialize(using = CustomOffsetLocalDateSerializer.class)
    @JsonDeserialize(using = CustomOffsetLocalDateDeserializer.class)
    @NotNull
    private LocalDate date;

    public static RequestScoreMessageDto fromJson(String json) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(json, RequestScoreMessageDto.class);
        } catch (Exception ex) {
            throw new MapperReadValueException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
        }
    }
}
