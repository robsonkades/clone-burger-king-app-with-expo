package com.serasaconsumidor.antifraude.score.request.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.databind.ObjectMapper;

import com.serasaconsumidor.antifraude.score.request.exception.MapperReadValueException;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SubscriptionMessageDto {
    private SubscriptionDto data;

    public static SubscriptionMessageDto fromJson(String json) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(json, SubscriptionMessageDto.class);
        } catch (Exception ex) {
            throw new MapperReadValueException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
        }
    }
}
