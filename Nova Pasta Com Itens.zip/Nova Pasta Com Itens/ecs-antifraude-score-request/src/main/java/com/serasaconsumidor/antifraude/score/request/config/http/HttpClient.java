package com.serasaconsumidor.antifraude.score.request.config.http;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

@RequiredArgsConstructor
public class HttpClient {

    @Autowired
    protected RestTemplate restTemplate;

    @Autowired
    protected ClientUrl clientUrl;

    @Autowired
    protected RequestContext requestContext;
}