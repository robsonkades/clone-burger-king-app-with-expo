package com.serasaconsumidor.antifraude.score.request.config.aws.sqs;

import lombok.AllArgsConstructor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.support.destination.DynamicDestinationResolver;

import javax.jms.Session;

import com.amazon.sqs.javamessaging.ProviderConfiguration;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSAsyncClientBuilder;

@EnableJms
@Configuration
@AllArgsConstructor
public class SqsConfig {

    @Bean
    public AmazonSQS amazonSqs(final SqsProperties sqsProperties) {
        return AmazonSQSAsyncClientBuilder.standard()
                .withRegion(sqsProperties.getRegion())
                .build();
    }

    @Bean
    public SQSConnectionFactory sqsConnectionFactory(final ProviderConfiguration providerConfiguration, final AmazonSQS amazonSQS) {
        return new SQSConnectionFactory(providerConfiguration, amazonSQS);
    }

    @Bean
    public ProviderConfiguration providerConfiguration(final SqsProperties sqsProperties) {
        final ProviderConfiguration providerConfiguration = new ProviderConfiguration();
        providerConfiguration.setNumberOfMessagesToPrefetch(sqsProperties.getNumberMessagesOfPrefetch());
        return providerConfiguration;
    }

    @Bean
    public JmsListenerContainerFactory<DefaultMessageListenerContainer> jmsListenerContainerFactory(final SQSConnectionFactory sqsConnectionFactory, final SqsProperties sqsProperties) {
        final DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        factory.setConnectionFactory(sqsConnectionFactory);
        factory.setDestinationResolver(new DynamicDestinationResolver());
        factory.setConcurrency(sqsProperties.getConcurrency());
        factory.setSessionAcknowledgeMode(Session.CLIENT_ACKNOWLEDGE);
        factory.setMaxMessagesPerTask(sqsProperties.getMaxMessagesPerTask());
        factory.setAutoStartup(true);
        return factory;
    }

    @Bean
    public JmsTemplate defaultJmsTemplate(final SQSConnectionFactory sqsConnectionFactory) {
        var template = new JmsTemplate(sqsConnectionFactory);
        return template;
    }
}
