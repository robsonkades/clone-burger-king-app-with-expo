package com.serasaconsumidor.antifraude.score.request.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.serasaconsumidor.antifraude.score.request.utils.CustomOffsetLocalDateDeserializer;
import com.serasaconsumidor.antifraude.score.request.utils.CustomOffsetLocalDateSerializer;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class ScoreUpdateDto {

    private long score;

    @JsonSerialize(using = CustomOffsetLocalDateSerializer.class)
    @JsonDeserialize(using = CustomOffsetLocalDateDeserializer.class)
    @JsonProperty("ingestion_date")
    private LocalDate ingestionDate;

    private String model;

    private ScoreNumberMessageDto message;

    private SubscriptionDto subscription;
}
