package com.serasaconsumidor.antifraude.score.request.config.aws.sqs;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.model.SendMessageBatchRequest;
import com.amazonaws.services.sqs.model.SendMessageBatchRequestEntry;
import com.amazonaws.services.sqs.model.SendMessageBatchResult;
import com.amazonaws.services.sqs.model.SendMessageRequest;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.Lists;

import java.util.Collections;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

import com.serasaconsumidor.antifraude.score.request.constants.Constants;
import com.serasaconsumidor.antifraude.score.request.dtos.MessageEventProducerDto;

@Slf4j
@Service
@AllArgsConstructor
public class SqsProducerImpl implements SqsProducer {

    private final AmazonSQS sqsClient;
    private final ObjectMapper objectMapper;
    private final SqsProperties sqsProperties;

    @Override
    @Async
    public <T> void sendMessage(T message, String queue) {
        try {
            var sendMessageRequest = new SendMessageRequest()
                    .withQueueUrl(queue)
                    .withDelaySeconds(sqsProperties.getDelay())
                    .withMessageBody(toJson(message));

            var response = sqsClient.sendMessage(sendMessageRequest);
            log.info("Message send to SQS with message id: {}", response.getMessageId());
         } catch (Exception e) {
        log.error("Error send message to SQS, {}", e.getMessage());
        }
    }

    @Override
    public void sendMessageBatch(List<?> messages, String queue) {

        List<String> messagesJson = messages
                .stream()
                .map(this::toJson)
                .filter(item -> !StringUtils.isEmpty(item))
                .collect(Collectors.toList());

        Lists.partition(messagesJson, Constants.MAX_BATCH_SEND_SQS)
                .parallelStream().forEach(strings -> {
                    try {

                        final AtomicInteger index = new AtomicInteger();
                        final List<SendMessageBatchRequestEntry> entries = strings.stream()
                                .map(message -> {
                                    final String messageId = String.valueOf(index.getAndIncrement());
                                    var request = new SendMessageBatchRequestEntry(messageId, message);
                                    request.setDelaySeconds(sqsProperties.getDelay());
                                    return request;
                                }).collect(Collectors.toList());

                        var sendMessageRequest = new SendMessageBatchRequest()
                                .withQueueUrl(queue)
                                .withEntries(entries);

                        SendMessageBatchResult resultFuture = sqsClient.sendMessageBatch(sendMessageRequest);

                        resultFuture
                                .getSuccessful()
                                .stream()
                                .forEach(sendMessageBatchResultEntry ->
                                        log.info("Message send to SQS with message id: {}", sendMessageBatchResultEntry.getMessageId()));

                    } catch (Exception e) {
                        log.error("Error send message batch to SQS, {}", e.getMessage());
                    }
                });
    }

    private String toJson(Object message) {
        try {
            MessageEventProducerDto messageDto = MessageEventProducerDto.builder().data(message).build();
            return objectMapper.writeValueAsString(messageDto);
        } catch (JsonProcessingException ex) {
            return "";
        }
    }
}