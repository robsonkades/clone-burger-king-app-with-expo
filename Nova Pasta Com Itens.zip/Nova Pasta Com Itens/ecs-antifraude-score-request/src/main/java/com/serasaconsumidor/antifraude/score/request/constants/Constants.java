package com.serasaconsumidor.antifraude.score.request.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Constants {

    public static final String SNS_EVENT_TYPE = "X-Event-Type";
    public static final String STACK_EVENTS_SNS_FILTER = "generate-event";
    public static final String NATURAL_PERSON = "PF";
    public static final int MAX_BATCH_SEND_SQS = 10;
    public static final String CACHE_KEY = "score:score-monitoring:%s";
    public static final String EVENT_PROCESS_SCORE_MONITORING = "MONITORING";
    public static final String SCORE_BATCH_KEY = "score:batch";

    public static String getScoreMonitoringCacheKey(String subscriptionCode) {
        return String.format(CACHE_KEY, subscriptionCode);
    }
}
