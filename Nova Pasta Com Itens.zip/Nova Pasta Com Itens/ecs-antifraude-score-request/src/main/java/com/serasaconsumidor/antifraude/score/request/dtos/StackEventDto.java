package com.serasaconsumidor.antifraude.score.request.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class StackEventDto {

    private String document;
    private String eventCode;
    private String userId;
    private String serviceOrigin;
    private String userType;
    private String clientOrigin;
    private Object data;
}
