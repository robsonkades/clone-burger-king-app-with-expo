package com.serasaconsumidor.antifraude.score.request.listeners.impl;

import com.serasaconsumidor.antifraude.score.request.config.ServerProperties;
import com.serasaconsumidor.antifraude.score.request.config.aws.sns.SnsProducer;
import com.serasaconsumidor.antifraude.score.request.config.aws.sns.SnsProperties;
import com.serasaconsumidor.antifraude.score.request.config.aws.sqs.SqsProducer;
import com.serasaconsumidor.antifraude.score.request.config.aws.sqs.SqsProperties;
import com.serasaconsumidor.antifraude.score.request.config.http.clients.Score;
import com.serasaconsumidor.antifraude.score.request.config.redis.RedisManager;
import com.serasaconsumidor.antifraude.score.request.constants.Constants;
import com.serasaconsumidor.antifraude.score.request.constants.Events;
import com.serasaconsumidor.antifraude.score.request.dtos.RequestScoreNumberDto;
import com.serasaconsumidor.antifraude.score.request.dtos.ScoreNumberDto;
import com.serasaconsumidor.antifraude.score.request.dtos.ScoreUpdateDto;
import com.serasaconsumidor.antifraude.score.request.dtos.StackEventDto;
import com.serasaconsumidor.antifraude.score.request.dtos.SubscriptionDto;
import com.serasaconsumidor.antifraude.score.request.dtos.SubscriptionMessageDto;
import com.serasaconsumidor.antifraude.score.request.listeners.UpdatedScoreListener;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.Optional;

import static com.serasaconsumidor.antifraude.score.request.constants.Constants.STACK_EVENTS_SNS_FILTER;

@Slf4j
@AllArgsConstructor
@Component
public class UpdatedScoreListenerImpl implements UpdatedScoreListener {

    Score score;
    ServerProperties serverProperties;
    SnsProducer snsProducer;
    SnsProperties snsProperties;
    RedisManager redisManager;
    SqsProperties sqsProperties;
    SqsProducer sqsProducer;

    @Override
    @JmsListener(destination = "${aws.sqs.requestScoreQueue}")
    public void messageConsumer(@Payload String message, @Headers Map<String, Object> headers) {
        var subscriptionMessage = SubscriptionMessageDto.fromJson(message);
        SubscriptionDto subscription = subscriptionMessage.getData();

        var hasNotified = redisManager.hasKey(Constants.getScoreMonitoringCacheKey(subscription.getSubscriptionCode()));

        if (hasNotified) {
            log.info("user has already been notified {}", subscription.getUserId());
            return;
        }

        log.info("Processing new score to userId {}", subscription.getUserId());

        var stackEventPayload = StackEventDto
                .builder()
                .document(subscription.getDocument())
                .userId(subscription.getUserId().toString())
                .clientOrigin(serverProperties.getClient())
                .serviceOrigin(serverProperties.getName())
                .userType(Constants.NATURAL_PERSON);

        try {
            snsProducer.sendMessage(stackEventPayload.eventCode(Events.REQUEST_SCORE_NUMBER).build(), snsProperties.getTopicArnStackEvents(), STACK_EVENTS_SNS_FILTER);
        } catch (Exception ex) {
            log.error("Error sending stackEvent {}", ex.getMessage());
        }

        RequestScoreNumberDto payload = RequestScoreNumberDto
                .builder()
                .document(subscription.getDocument())
                .userId(subscription.getUserId())
                .build();

        Optional<ScoreNumberDto> scoreNumberDto = score.getScore(payload);

        scoreNumberDto.ifPresentOrElse(responseScoreNumberDto -> {
                    try {
                        snsProducer.sendMessage(stackEventPayload
                                .eventCode(Events.NEW_SCORE_NUMBER)
                                .build(), snsProperties.getTopicArnStackEvents(), STACK_EVENTS_SNS_FILTER);
                    } catch (Exception ex) {
                        log.error("Error sending stackEvent {}", ex.getMessage());
                    }
                    var scoreUpdated = ScoreUpdateDto
                            .builder()
                            .ingestionDate(responseScoreNumberDto.getIngestionDate())
                            .model(responseScoreNumberDto.getModel())
                            .message(responseScoreNumberDto.getMessage())
                            .score(responseScoreNumberDto.getScore())
                            .subscription(subscription)
                            .build();

                    log.info("Send message to process score to userId {}", scoreUpdated.getSubscription().getUserId());
                    sqsProducer.sendMessage(scoreUpdated, sqsProperties.getUpdatedRequestQueue());
                },
                () -> {
                    try {
                        snsProducer.sendMessage(stackEventPayload.eventCode(Events.SCORE_NUMBER_NOT_FOUND).build(), snsProperties.getTopicArnStackEvents(), STACK_EVENTS_SNS_FILTER);
                    } catch (Exception ex) {
                        log.error("Error sending stackEvent {}", ex.getMessage());
                    }
                    log.warn("No score found to userId {}", subscription.getUserId());
                });
    }
}
