package com.serasaconsumidor.antifraude.score.request.services.impl;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.UUID;

import com.serasaconsumidor.antifraude.score.request.config.http.clients.Subscription;
import com.serasaconsumidor.antifraude.score.request.dtos.BaseResponseListDto;
import com.serasaconsumidor.antifraude.score.request.dtos.SubscriptionDto;
import com.serasaconsumidor.antifraude.score.request.services.ListSubscriptionsByUserService;

@Service
@AllArgsConstructor
public class ListSubscriptionsByUserServiceImpl implements ListSubscriptionsByUserService {

    Subscription subscription;

    @Override
    public Optional<BaseResponseListDto<SubscriptionDto>> execute(UUID userId) {
        return subscription.listAllByUserId(userId);
    }
}
