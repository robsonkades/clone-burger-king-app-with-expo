package com.serasaconsumidor.antifraude.score.request.dtos;

import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class BaseResponseListDto<T> {
    private int totalPages;
    private int totalElements;
    private int pageSize;
    private List<T> data;
}
