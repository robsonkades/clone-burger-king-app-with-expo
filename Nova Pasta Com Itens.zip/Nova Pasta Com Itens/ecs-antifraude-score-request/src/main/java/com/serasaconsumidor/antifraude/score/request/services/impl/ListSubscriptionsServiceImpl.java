package com.serasaconsumidor.antifraude.score.request.services.impl;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.Optional;

import com.serasaconsumidor.antifraude.score.request.config.http.clients.Subscription;
import com.serasaconsumidor.antifraude.score.request.dtos.BaseResponseListDto;
import com.serasaconsumidor.antifraude.score.request.dtos.SubscriptionDto;
import com.serasaconsumidor.antifraude.score.request.services.ListSubscriptionsService;

@Service
@AllArgsConstructor
public class ListSubscriptionsServiceImpl implements ListSubscriptionsService {

    Subscription subscription;

    @Override
    public Optional<BaseResponseListDto<SubscriptionDto>> execute(int size, int page) {
        return subscription.listAll(size, page);
    }
}
