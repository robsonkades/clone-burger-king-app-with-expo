package com.serasaconsumidor.antifraude.score.request.job;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;

import com.serasaconsumidor.antifraude.score.request.config.http.clients.ScoreBatch;
import com.serasaconsumidor.antifraude.score.request.config.redis.RedisManager;
import com.serasaconsumidor.antifraude.score.request.constants.Constants;
import com.serasaconsumidor.antifraude.score.request.dtos.ProcessScoreModelDto;
import com.serasaconsumidor.antifraude.score.request.services.ProcessScoreService;

@EnableAsync
@Component
@AllArgsConstructor
@Slf4j
public class ScoreMonitorJob {

    ProcessScoreService processScoreService;
    RedisManager redisManager;
    ScoreBatch scoreBatch;

    /**
     * Esse Cron tem o objetivo de iniciar o batch de processamento do score free e premium
     * É programado para iniciar a cada 30 minutos, verificamod no cache quantos modelos já foram processados pelo lake,
     * quando os três modelos forem importados, disparamos o processamento do score, caso aconteça de algum dia importar apenas um ou dois
     * modelos, aguardamos 12 horas até o últimos modelo ser importado, caso isso não ocorra iniciamos o processamento do score
     * @throws InterruptedException
     */
    @Async
    @Scheduled(cron = "0 */30 * ? * *")
    public void scheduleFixedRateTaskAsync() throws InterruptedException {
        var processScoreModelDtoOptional = redisManager.findValue(Constants.SCORE_BATCH_KEY, ProcessScoreModelDto.class);
        if (processScoreModelDtoOptional.isPresent()) {
            var processScoreModelDto = processScoreModelDtoOptional.get();
            if (processScoreModelDto.getSize() >= 3 || LocalDateTime.now().minusHours(12).isAfter(processScoreModelDto.getLastUpdate())) {
                var hasDeleted = redisManager.delete(Constants.SCORE_BATCH_KEY);
                if (hasDeleted) {
                    scoreBatch.runBatch("SCORE_MONITOR_FREE");
                    processScoreService.execute();
                }
            }
        }
    }
}
