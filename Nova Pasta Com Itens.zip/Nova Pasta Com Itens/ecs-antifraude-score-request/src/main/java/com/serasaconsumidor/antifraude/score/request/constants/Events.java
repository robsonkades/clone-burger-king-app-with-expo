package com.serasaconsumidor.antifraude.score.request.constants;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Events {

    public static final String SCORE_UPDATED = "3303";
    public static final String REQUEST_SCORE_NUMBER = "3300";
    public static final String NEW_SCORE_NUMBER = "3301";
    public static final String SCORE_NUMBER_NOT_FOUND = "3302";

}
