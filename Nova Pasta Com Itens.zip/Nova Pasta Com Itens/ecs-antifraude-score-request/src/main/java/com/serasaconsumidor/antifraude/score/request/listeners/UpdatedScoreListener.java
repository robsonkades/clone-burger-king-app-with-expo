package com.serasaconsumidor.antifraude.score.request.listeners;

import java.util.Map;

public interface UpdatedScoreListener {
    void messageConsumer(String message, Map<String, Object> headers);
}
