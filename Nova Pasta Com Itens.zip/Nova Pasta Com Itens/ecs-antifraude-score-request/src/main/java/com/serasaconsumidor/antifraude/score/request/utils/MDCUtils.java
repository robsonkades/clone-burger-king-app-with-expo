package com.serasaconsumidor.antifraude.score.request.utils;

import org.slf4j.MDC;

import java.util.Map;

public class MDCUtils {

    public static void startMDC(Map<String, Object> headers) {
        headers.forEach((k, v) -> MDC.put(k, v.toString()));
    }

    public static void removeMDC(Map<String, Object> headers) {
        headers.forEach((k, v) -> MDC.remove(k));
    }

}
