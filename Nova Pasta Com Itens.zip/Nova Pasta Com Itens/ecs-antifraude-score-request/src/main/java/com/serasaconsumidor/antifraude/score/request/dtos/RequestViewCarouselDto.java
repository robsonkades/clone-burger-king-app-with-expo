package com.serasaconsumidor.antifraude.score.request.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;
import java.util.UUID;

@Getter
@Setter
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestViewCarouselDto {

    @NotNull
    private String document;
    @NotNull
    private UUID userId;
}
