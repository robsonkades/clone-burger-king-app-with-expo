package com.serasaconsumidor.antifraude.score.request.services;

import java.util.Optional;

import com.serasaconsumidor.antifraude.score.request.dtos.BaseResponseListDto;
import com.serasaconsumidor.antifraude.score.request.dtos.SubscriptionDto;

public interface ListSubscriptionsService {
    Optional<BaseResponseListDto<SubscriptionDto>> execute(int size, int page);
}
