package com.serasaconsumidor.antifraude.score.request.services;

import com.serasaconsumidor.antifraude.score.request.dtos.RequestViewCarouselDto;

public interface CreateViewCarouselService {

    String execute(RequestViewCarouselDto request);
}
