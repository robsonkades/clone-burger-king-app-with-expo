package com.serasaconsumidor.antifraude.score.request.config.aws.sns;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.amazonaws.services.sns.AmazonSNSAsync;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

import com.serasaconsumidor.antifraude.score.request.constants.Constants;
import com.serasaconsumidor.antifraude.score.request.dtos.MessageEventProducerDto;
import com.serasaconsumidor.antifraude.score.request.exception.SnsProducerException;


@Slf4j
@Service
@RequiredArgsConstructor
public class SnsProducerImpl implements SnsProducer {

    private final AmazonSNSAsync snsClient;
    private final ObjectMapper objectMapper;

    @Override
    @Async
    public void sendMessage(Object message, String topicArn, String eventType) {
        try {
            log.info("Building the message to send by async method");
            Map<String, MessageAttributeValue> attributes = new HashMap<>();
            attributes.put(Constants.SNS_EVENT_TYPE, new MessageAttributeValue()
                    .withDataType("String").withStringValue(eventType));

            MessageEventProducerDto messageDto = MessageEventProducerDto.builder().data(message).build();
            String messageAsJson = objectMapper.writeValueAsString(messageDto);

            PublishRequest publishRequest = new PublishRequest()
                    .withMessageAttributes(attributes)
                    .withTopicArn(topicArn)
                    .withMessage(messageAsJson);

            Future<PublishResult> resultFuture = snsClient.publishAsync(publishRequest);
            log.info("The async message was send to SNS with message id: {}", resultFuture.get().getMessageId());
        } catch (Exception exc) {
            throw new SnsProducerException(HttpStatus.BAD_REQUEST,exc.getMessage());
        }
    }
}