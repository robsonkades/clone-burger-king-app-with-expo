package com.serasaconsumidor.antifraude.score.request.dtos;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.time.LocalDateTime;

@Getter
@Setter
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProcessScoreModelDto {

    private String model;
    private int size;
    private LocalDateTime lastUpdate;

}
