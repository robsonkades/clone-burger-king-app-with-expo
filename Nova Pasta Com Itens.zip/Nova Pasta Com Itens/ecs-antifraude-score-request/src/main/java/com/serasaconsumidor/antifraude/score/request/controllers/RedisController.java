package com.serasaconsumidor.antifraude.score.request.controllers;

import com.serasaconsumidor.antifraude.score.request.config.redis.RedisManager;
import com.serasaconsumidor.antifraude.score.request.constants.Constants;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/v1/redis")
@AllArgsConstructor
public class RedisController {

    private final RedisManager redisManager;

    @CrossOrigin(origins = "*")
    @DeleteMapping(path = "/{subscriptionCode}")
    public ResponseEntity<Boolean> delete(@PathVariable String subscriptionCode) {
        var key = Constants.getScoreMonitoringCacheKey(subscriptionCode);
        var exists = redisManager.hasKey(key);
        if (exists) {
            return ResponseEntity.ok(redisManager.delete(key));
        }
        return ResponseEntity.ok(Boolean.FALSE);
    }

    @CrossOrigin(origins = "*")
    @GetMapping(path = "/{subscriptionCode}")
    public ResponseEntity<String> read(@PathVariable String subscriptionCode) {
        var key = Constants.getScoreMonitoringCacheKey(subscriptionCode);
        var exist = redisManager.hasKey(key);
        if (exist) {
            return ResponseEntity.ok(key);
        }
        return ResponseEntity.status(HttpStatus.NO_CONTENT).build();
    }
}
