package com.serasaconsumidor.antifraude.score.request.dtos;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ScoreNumberMessageDto {
    private String title;
    private String subtitle;
}
