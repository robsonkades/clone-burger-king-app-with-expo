package com.serasaconsumidor.antifraude.score.request.services.impl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.CollectionUtils;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.serasaconsumidor.antifraude.score.request.config.aws.sqs.SqsProducer;
import com.serasaconsumidor.antifraude.score.request.config.aws.sqs.SqsProperties;
import com.serasaconsumidor.antifraude.score.request.dtos.BaseResponseListDto;
import com.serasaconsumidor.antifraude.score.request.dtos.SubscriptionDto;
import com.serasaconsumidor.antifraude.score.request.services.ListSubscriptionsByUserService;
import com.serasaconsumidor.antifraude.score.request.services.ProcessScoreUserService;

@Slf4j
@Service
@AllArgsConstructor
public class ProcessScoreUserServiceImpl implements ProcessScoreUserService {

    private final ListSubscriptionsByUserService listSubscriptionsByUserService;
    private final SqsProducer sqsProducer;
    private final SqsProperties sqsProperties;

    @Override
    public void execute(UUID userId) {
        log.info("Process score to userId {}", userId);

        Optional<BaseResponseListDto<SubscriptionDto>> subscriptionsPage = listSubscriptionsByUserService.execute(userId);

        subscriptionsPage.ifPresent((pageSubscriptions) -> {
            if (CollectionUtils.isNotEmpty(pageSubscriptions.getData())) {
                List<SubscriptionDto> subscriptions = pageSubscriptions.getData();
                sqsProducer.sendMessageBatch(subscriptions, sqsProperties.getRequestScoreQueue());
            }
        });
    }
}
