package com.serasaconsumidor.antifraude.score.request.dtos;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.serasaconsumidor.antifraude.score.request.exception.MapperReadValueException;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class ProcessScoreMessageDto {

    private ProcessScoreDataDto data;

    public static ProcessScoreMessageDto fromJson(String json) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(json, ProcessScoreMessageDto.class);
        } catch (Exception ex) {
            throw new MapperReadValueException(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
        }
    }
}
