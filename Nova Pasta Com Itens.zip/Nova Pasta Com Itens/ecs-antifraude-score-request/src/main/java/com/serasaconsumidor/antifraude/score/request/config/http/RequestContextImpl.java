package com.serasaconsumidor.antifraude.score.request.config.http;

import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.serasaconsumidor.antifraude.score.request.config.ServerProperties;

@RequiredArgsConstructor
@Service
public class RequestContextImpl implements RequestContext {

    private static final List<String> HEADERS_TO_FORWARD = List.of(
            "x-request-id", "x-forwarded-for",
            "user-agent", "origin", "referer",
            "x-consumer-id", "x-consumer-document",
            "x-event-type", "x-feature-groups",
            "x-subscription-id", "method", "path"
    );

    private final HttpServletRequest request;
    private final ServerProperties applicationProperties;

    @Override
    public Map<String, List<String>> getHeadersToForward() {
        Map<String, List<String>> headersMap = Collections
                .list(request.getHeaderNames())
                .stream()
                .filter(a -> HEADERS_TO_FORWARD.stream().anyMatch(str -> str.equalsIgnoreCase(a)))
                .collect(Collectors.toMap(
                        Function.identity(),
                        h -> Collections.list(request.getHeaders(h))
                ));

        headersMap.put("X-Client", Collections.singletonList(applicationProperties.getClient()));
        headersMap.put("X-Application", Collections.singletonList(applicationProperties.getName()));

        return headersMap;
    }

    @Override
    public HttpHeaders getHeaders(List<String> headersToForward) {
        HttpHeaders httpHeaders = new HttpHeaders();
        Enumeration headerNames = request.getHeaderNames();
        while (headerNames.hasMoreElements()) {
            String key = (String) headerNames.nextElement();
            if (headersToForward.contains(key.toLowerCase())) {
                String value = request.getHeader(key);
                httpHeaders.put(key, Collections.singletonList(value));
            }
        }
        return httpHeaders;
    }

    @Override
    public String getHeaderValue(String headerName) {
        return request.getHeader(headerName);
    }
}