package com.serasaconsumidor.antifraude.score.request.listeners.impl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.Map;

import com.serasaconsumidor.antifraude.score.request.dtos.RequestScoreMessageDto;
import com.serasaconsumidor.antifraude.score.request.listeners.SqsMessageListener;

@Component
@Slf4j
@AllArgsConstructor
public class SqsMessageListenerImpl implements SqsMessageListener {

    ApplicationEventPublisher eventPublisher;

    @Override
    @JmsListener(destination = "${aws.sqs.loadScoreQueue}")
    public void messageConsumer(@Payload String message, @Headers Map<String, Object> headers) {
        log.info("Receiving load score finished event: {}", message);
        try {
            var scoreMessage = RequestScoreMessageDto.fromJson(message);
            eventPublisher.publishEvent(scoreMessage);
        } catch (Exception ex) {
            log.error("Error receiver score process", ex.getMessage());
            throw ex;
        }
    }
}
