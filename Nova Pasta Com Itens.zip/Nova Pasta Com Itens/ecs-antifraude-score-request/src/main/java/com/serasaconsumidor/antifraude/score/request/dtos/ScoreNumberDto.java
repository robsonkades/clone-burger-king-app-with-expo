package com.serasaconsumidor.antifraude.score.request.dtos;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.serasaconsumidor.antifraude.score.request.utils.CustomOffsetLocalDateDeserializer;
import com.serasaconsumidor.antifraude.score.request.utils.CustomOffsetLocalDateSerializer;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ScoreNumberDto {
    private long score;

    private String model;

    private ScoreNumberMessageDto message;

    @JsonProperty("ingestion_date")
    @JsonSerialize(using = CustomOffsetLocalDateSerializer.class)
    @JsonDeserialize(using = CustomOffsetLocalDateDeserializer.class)
    private LocalDate ingestionDate;
}
