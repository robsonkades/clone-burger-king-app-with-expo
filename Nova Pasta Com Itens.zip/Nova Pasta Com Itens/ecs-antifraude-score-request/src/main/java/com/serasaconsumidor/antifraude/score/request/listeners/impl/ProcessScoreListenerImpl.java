package com.serasaconsumidor.antifraude.score.request.listeners.impl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.Map;

import com.serasaconsumidor.antifraude.score.request.dtos.ProcessScoreMessageDto;
import com.serasaconsumidor.antifraude.score.request.listeners.ProcessScoreListener;
import com.serasaconsumidor.antifraude.score.request.services.ProcessScorePagedSubscriptions;

@Slf4j
@AllArgsConstructor
@Component
public class ProcessScoreListenerImpl implements ProcessScoreListener {

    private final ProcessScorePagedSubscriptions processScorePagedSubscriptions;

    @Override
    @JmsListener(destination = "${aws.sqs.scoreProcessQueue}")
    public void messageConsumer(@Payload String message, @Headers Map<String, Object> headers) {
        log.info("Receiving load score finished event: {}", message);
        try {
            var processScoreMessage = ProcessScoreMessageDto.fromJson(message);
            processScorePagedSubscriptions.execute(processScoreMessage);
        } catch (Exception ex) {
            log.error("Error receiver score process", ex.getMessage());
            throw ex;
        }
    }
}
