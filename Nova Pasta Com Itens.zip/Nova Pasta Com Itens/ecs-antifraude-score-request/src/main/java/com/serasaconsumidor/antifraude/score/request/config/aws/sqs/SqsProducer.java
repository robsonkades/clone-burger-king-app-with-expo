package com.serasaconsumidor.antifraude.score.request.config.aws.sqs;

import java.util.List;

public interface SqsProducer {
    void sendMessageBatch(List<?> message, String queue);

    <T> void sendMessage(T message, String queue);
}
