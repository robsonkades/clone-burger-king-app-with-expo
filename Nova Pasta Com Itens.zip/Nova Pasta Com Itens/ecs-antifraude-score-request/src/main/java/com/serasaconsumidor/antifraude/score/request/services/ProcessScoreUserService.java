package com.serasaconsumidor.antifraude.score.request.services;

import java.util.UUID;

public interface ProcessScoreUserService {
    void execute(UUID userId);
}
