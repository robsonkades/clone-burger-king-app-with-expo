package com.serasaconsumidor.antifraude.score.request.services;

import java.util.Optional;
import java.util.UUID;

import com.serasaconsumidor.antifraude.score.request.dtos.BaseResponseListDto;
import com.serasaconsumidor.antifraude.score.request.dtos.SubscriptionDto;

public interface ListSubscriptionsByUserService {
    Optional<BaseResponseListDto<SubscriptionDto>> execute(UUID userId);
}
