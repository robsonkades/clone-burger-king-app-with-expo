package com.serasaconsumidor.antifraude.score.request.services.impl;

import com.serasaconsumidor.antifraude.score.request.domain.CarouselTotalViewEntity;
import com.serasaconsumidor.antifraude.score.request.dtos.RequestViewCarouselDto;
import com.serasaconsumidor.antifraude.score.request.repository.CarouselTotalViewRepository;
import com.serasaconsumidor.antifraude.score.request.services.CreateViewCarouselService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Slf4j
@Service
@AllArgsConstructor
public class CreateViewCarouselServiceImpl implements CreateViewCarouselService {

    private final CarouselTotalViewRepository repository;

    @Override
    @Transactional
    public String execute(RequestViewCarouselDto request) {
        boolean exists = repository.existsByUserId(request.getUserId());
        if (!exists) {
            CarouselTotalViewEntity entity = CarouselTotalViewEntity.builder()
                    .userId(request.getUserId())
                    .previewDate(LocalDateTime.now())
                    .build();
            repository.save(entity);
            return "Success";
        }
        return "User already set";
    }

}
