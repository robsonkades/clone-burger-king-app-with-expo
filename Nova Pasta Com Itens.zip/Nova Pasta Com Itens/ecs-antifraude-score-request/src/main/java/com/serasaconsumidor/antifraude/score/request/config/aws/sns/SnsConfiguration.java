package com.serasaconsumidor.antifraude.score.request.config.aws.sns;

import com.amazonaws.regions.RegionUtils;
import com.amazonaws.services.sns.AmazonSNSAsync;
import com.amazonaws.services.sns.AmazonSNSAsyncClientBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SnsConfiguration {

    @Bean
    public AmazonSNSAsync ssnClient(final SnsProperties snsProperties) {
        return AmazonSNSAsyncClientBuilder
                .standard()
                .withRegion(String.valueOf(RegionUtils.getRegion(snsProperties.getRegion()))).build();
    }
}

