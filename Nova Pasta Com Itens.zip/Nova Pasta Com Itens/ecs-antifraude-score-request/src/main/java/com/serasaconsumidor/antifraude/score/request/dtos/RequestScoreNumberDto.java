package com.serasaconsumidor.antifraude.score.request.dtos;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.UUID;

@Getter
@Setter
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class RequestScoreNumberDto {
    @NotNull
    private String document;
    private UUID userId;
}
