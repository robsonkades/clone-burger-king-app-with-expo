package com.serasaconsumidor.antifraude.score.request.dtos;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class MessageEventProducerDto {
    private Object data;
}
