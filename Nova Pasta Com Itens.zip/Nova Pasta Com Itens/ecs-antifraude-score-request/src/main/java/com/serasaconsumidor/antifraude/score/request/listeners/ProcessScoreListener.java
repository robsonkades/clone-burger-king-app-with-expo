package com.serasaconsumidor.antifraude.score.request.listeners;

import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;

import java.util.Map;

public interface ProcessScoreListener {

    void messageConsumer(@Payload String message, @Headers Map<String, Object> headers);
}
