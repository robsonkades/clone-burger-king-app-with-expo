package com.serasaconsumidor.antifraude.score.request.config.http;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;

import com.serasaconsumidor.antifraude.score.request.interceptors.RestTemplateInterceptor;

@Configuration
public class CustomRestTemplate {

    private static final long DEFAULT_TIMEOUT = 10000;

    @Bean
    public RestTemplate restTemplate(final RestTemplateBuilder restTemplateBuilder, final CustomRestTemplateError restTemplateError, final RestTemplateInterceptor restTemplateInterceptor) {
        var rest = restTemplateBuilder
                .setConnectTimeout(Duration.ofMillis(DEFAULT_TIMEOUT))
                .setReadTimeout(Duration.ofMillis(DEFAULT_TIMEOUT))
                .errorHandler(restTemplateError).build();
        rest.getInterceptors().add(restTemplateInterceptor);
        return rest;
    }
}