package com.serasaconsumidor.antifraude.score.request.config.http;

import org.springframework.http.HttpHeaders;

import java.util.List;
import java.util.Map;

public interface RequestContext {
    Map<String, List<String>> getHeadersToForward();
    HttpHeaders getHeaders(List<String> headersToForward);
    String getHeaderValue(String header);
}
