package com.serasaconsumidor.antifraude.csid.dto;

import lombok.Builder;
import lombok.Data;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlRootElement;

@Data
@Builder
@JacksonXmlRootElement(localName = "EXTPOSTTRANSACTION")
public class TransactionDto {

    @JacksonXmlProperty(localName = "STLTRANSACTIONINFO")
    TransactionInfoDto info;

    @JacksonXmlProperty(localName = "EXTTRANSACTIONDATA")
    IdentityPayloadDto data;
}
