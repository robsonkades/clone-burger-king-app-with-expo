package com.serasaconsumidor.antifraude.csid.config.client;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.time.OffsetDateTime;

import com.serasaconsumidor.antifraude.csid.controller.exception.Error;
import com.serasaconsumidor.antifraude.csid.dto.BaseResponseDto;
import com.serasaconsumidor.antifraude.csid.dto.CSIDResponseDto;
import com.serasaconsumidor.antifraude.csid.dto.TransactionDto;

@Component
@Slf4j
public class CSIDClient extends BaseClient {

    public BaseResponseDto execute(TransactionDto payload) {

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_XML);
        HttpEntity<?> request = new HttpEntity<>(payload, headers);
        String url = csidConfig.getHost();
        ResponseEntity<CSIDResponseDto> response = restTemplate.postForEntity(url, request, CSIDResponseDto.class);
        var body = response.getBody();

        if (!body.getData().getCode().equals("OK")) {
            throw Error.getCause(body.getData().getCode());
        }

        return BaseResponseDto
                .builder()
                .data(body.getData())
                .transactionId(body.getInfo().getTransactionId())
                .date(OffsetDateTime.now())
                .build();

    }
}
