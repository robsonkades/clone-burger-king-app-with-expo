package com.serasaconsumidor.antifraude.csid.dto;

import lombok.Builder;
import lombok.Data;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@Data
@Builder
public class GeoCodeDto {

    @JacksonXmlProperty(localName = "IDLAT")
    private String latitude;

    @JacksonXmlProperty(localName = "IDLONG")
    private String longitude;
}
