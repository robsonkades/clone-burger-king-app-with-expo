package com.serasaconsumidor.antifraude.csid.controller;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

import java.util.Map;

import com.serasaconsumidor.antifraude.csid.dto.MemberPayloadDto;
import com.serasaconsumidor.antifraude.csid.service.CSIDService;

@RestController
@RequestMapping("v1/monitoring")
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class MonitoringController {

    Map<String, CSIDService> csidService;

    @PostMapping(produces = "application/xml", consumes = "application/json")
    public Object create(@RequestBody @Valid MemberPayloadDto dto) {
        return csidService.get("ENABLE_MONITORING").execute(dto);
    }

    @DeleteMapping(produces = "application/xml", consumes = "application/json")
    public Object delete(@RequestBody @Valid MemberPayloadDto dto) {
        return csidService.get("DISABLE_MONITORING").execute(dto);
    }
}
