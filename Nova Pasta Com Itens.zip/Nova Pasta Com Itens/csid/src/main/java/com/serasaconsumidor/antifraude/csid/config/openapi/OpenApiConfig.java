package com.serasaconsumidor.antifraude.csid.config.openapi;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import lombok.AllArgsConstructor;
import org.springdoc.core.GroupedOpenApi;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.serasaconsumidor.antifraude.csid.config.ApplicationConfig;

@Configuration
@AllArgsConstructor
public class OpenApiConfig {

    private ApplicationConfig applicationConfig;

    @Bean
    public OpenAPI openAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title(applicationConfig.getName())
                        .description(applicationConfig.getDescription())
                        .contact(new Contact()
                                .name("Premium")
                                .email("contato@serasa.com.br"))
                        .version(applicationConfig.getVersion())
                        .license(new License().name("Apache 2.0")
                                .url("www.serasa.com.br"))
                );

    }

    @Bean
    public GroupedOpenApi v1() {
        String[] paths = {"/v1/**"};
        return GroupedOpenApi.builder()
                .group("v1")
                .pathsToMatch(paths)
                .build();
    }
}
