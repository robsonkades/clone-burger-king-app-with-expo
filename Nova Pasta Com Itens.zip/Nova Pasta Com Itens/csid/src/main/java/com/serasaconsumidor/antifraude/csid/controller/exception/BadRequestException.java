package com.serasaconsumidor.antifraude.csid.controller.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class BadRequestException extends ResponseStatusException {

    public BadRequestException(HttpStatus statusCode, String error) {
        super(statusCode, error);
    }
}
