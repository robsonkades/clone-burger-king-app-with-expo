package com.serasaconsumidor.antifraude.csid.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import com.serasaconsumidor.antifraude.csid.util.XmlDeserializer;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TransactionDataResponseDto {

    @JacksonXmlProperty(localName = "ERRORCODE")
    String code;

    @JsonDeserialize(using = XmlDeserializer.class)
    @JacksonXmlProperty(localName = "RESPONSE")
    RecordDto[] reports;

    @JacksonXmlProperty(localName = "RESPONSEMETADATA")
    MetadataResponseDto metadata;
}
