package com.serasaconsumidor.antifraude.csid.service.impl;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;

import java.util.UUID;

import com.serasaconsumidor.antifraude.csid.config.CSIDConfig;
import com.serasaconsumidor.antifraude.csid.config.client.CSIDClient;
import com.serasaconsumidor.antifraude.csid.dto.BaseResponseDto;
import com.serasaconsumidor.antifraude.csid.dto.IdentityPayloadDto;
import com.serasaconsumidor.antifraude.csid.dto.MemberPayloadDto;
import com.serasaconsumidor.antifraude.csid.dto.TransactionDto;
import com.serasaconsumidor.antifraude.csid.dto.TransactionInfoDto;
import com.serasaconsumidor.antifraude.csid.service.CSIDService;

@Service(value = "PATCH_MEMBER")
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PatchMemberServiceImpl implements CSIDService {

    CSIDClient csidClient;
    CSIDConfig csidConfig;

    @Override
    public BaseResponseDto execute(MemberPayloadDto dto) {
        var remove =  TransactionInfoDto
                .builder()
                .userId(csidConfig.getUsername())
                .password(csidConfig.getPassword())
                .serviceCode("538")
                .transactionId(UUID.randomUUID().toString())
                .version(null)
                .build();

        var add =  TransactionInfoDto
                .builder()
                .password("AZb3r93ZuGU*+6+@J")
                .serviceCode("536")
                .transactionId(UUID.randomUUID().toString())
                .userId("experian_brazil")
                .version(null)
                .build();

        var payloadToRemove = TransactionDto.builder()
                .data(IdentityPayloadDto
                        .builder()
                        .identity(dto)
                        .build())
                .info(remove).build();

        var payloadToAdd = TransactionDto.builder()
                .data(IdentityPayloadDto
                        .builder()
                        .identity(dto)
                        .build())
                .info(add).build();

        csidClient.execute(payloadToRemove);
        return csidClient.execute(payloadToAdd);
    }
}
