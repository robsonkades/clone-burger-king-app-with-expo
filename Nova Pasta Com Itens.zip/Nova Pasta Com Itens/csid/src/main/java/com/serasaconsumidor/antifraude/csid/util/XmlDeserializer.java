package com.serasaconsumidor.antifraude.csid.util;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.deser.std.StdDeserializer;
import com.fasterxml.jackson.dataformat.xml.JacksonXmlModule;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;

import java.io.IOException;

import com.serasaconsumidor.antifraude.csid.dto.RecordDto;

public class XmlDeserializer extends StdDeserializer<RecordDto[]> {

    public XmlDeserializer() {
        this(null);
    }

    public XmlDeserializer(Class<?> vc) {
        super(vc);
    }

    @Override
    public RecordDto[] deserialize(JsonParser jsonParser, DeserializationContext deserializationContext) throws IOException, JsonProcessingException {
        try {
            JacksonXmlModule xmlModule = new JacksonXmlModule();
            xmlModule.setDefaultUseWrapper(false);
            ObjectMapper objectMapper = new XmlMapper(xmlModule);
            return objectMapper.readValue(jsonParser.getText(), RecordDto[].class);
        } catch (Exception e) {
            return new RecordDto[0];
        }
    }
}
