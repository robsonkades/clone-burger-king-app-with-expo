package com.serasaconsumidor.antifraude.csid.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class IdentityPayloadDto {

    @JacksonXmlProperty(localName = "IDENTITY")
    private Object identity;
}
