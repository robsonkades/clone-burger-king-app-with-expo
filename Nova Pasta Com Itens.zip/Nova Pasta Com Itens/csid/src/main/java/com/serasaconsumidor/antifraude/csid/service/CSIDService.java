package com.serasaconsumidor.antifraude.csid.service;

import com.serasaconsumidor.antifraude.csid.dto.BaseResponseDto;
import com.serasaconsumidor.antifraude.csid.dto.MemberPayloadDto;

public interface CSIDService {

    BaseResponseDto execute(MemberPayloadDto dto);
}
