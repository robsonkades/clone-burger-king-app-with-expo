package com.serasaconsumidor.antifraude.csid.controller;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

import java.util.Map;

import com.serasaconsumidor.antifraude.csid.dto.MemberPayloadDto;
import com.serasaconsumidor.antifraude.csid.service.CSIDService;

@RestController
@RequestMapping("v1/reports")
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ReportController {

    Map<String, CSIDService> csidService;

    @GetMapping(produces = "application/json", consumes = "application/json")
    public Object index(@RequestBody @Valid MemberPayloadDto dto) {
        return csidService.get("CREATE_REPORT").execute(dto);
    }
}
