package com.serasaconsumidor.antifraude.csid.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class RecordDto {
    private String id;
    private String namefirst;
    private String namemid;
    private String namelast;
    private String addr1;
    private String addr2;
    private String addrcity;
    private String addrstate;
    private String addrzip;
    private String addrcountry;
    private String phone;
    private String phone1;
    private String phone2;
    private String phone3;
    private String phoneext;
    private String ssn;
    private String ssnlast4;
    private String natlid;
    private String mmn;
    private String dob;
    private String dobyear;
    private String dobmon;
    private String dobday;
    private String gender;
    private String dlnumber;
    private String dlstate;
    private String email;
    private String userid;
    private String password;
    private String cardtype;
    private String cardname;
    private String cardnum;
    private String md5cardnum;
    private String cardcvn;
    private String cardpin;
    private String cardexpdate;
    private String cardexpyear;
    private String cardexpmon;
    private String cardexpday;
    private String cardaddr;
    private String retailcardnum;
    private String cardbin;
    private String paypaluid;
    private String paypalpwd;
    private String ebayuid;
    private String ebaypwd;
    private String bankname;
    private String bankphone;
    private String bankroute;
    private String bankacct;
    private String bankuid;
    private String bankpwd;
    private String bankpin;
    private String iban;
    private String medicalid;
    private String medicalprovider;
    private String passportnum;
    private String passportexpdate;
    private String passportissuedate;
    private String passportcountry;
    private String sha1;
    private String site;
    private String Source;
    private String SourceDate;
    private String UpdateDate;
    private String CreationDate;
    private String sourcecategory;
    private String compromisetype;
    private String breachedsitecountry;
    private String breachedsite;
    private String breachedrecordcount;
    private String hacker;
    private String hackergroup;
    private String passwordstatus;
    private String hackingoperation;
    private String severity;
    private String motivation;
    private String breachedsector;
    private String note;
    private String match;
    private String synopsis_id;
    private String phishedkeyloggedsite;
}
