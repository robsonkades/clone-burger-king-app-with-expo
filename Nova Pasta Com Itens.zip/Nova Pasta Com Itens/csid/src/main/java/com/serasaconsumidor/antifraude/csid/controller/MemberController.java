package com.serasaconsumidor.antifraude.csid.controller;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.Valid;

import java.util.Map;

import com.serasaconsumidor.antifraude.csid.dto.BaseResponseDto;
import com.serasaconsumidor.antifraude.csid.dto.MemberPayloadDto;
import com.serasaconsumidor.antifraude.csid.service.CSIDService;

@RestController
@RequestMapping("v1/members")
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class MemberController {

    Map<String, CSIDService> csidService;

    @PostMapping(produces = "application/xml", consumes = "application/json")
    public BaseResponseDto create(@RequestBody @Valid MemberPayloadDto dto) {
        return csidService.get("CREATE_MEMBER").execute(dto);
    }

    @PutMapping(produces = "application/xml", consumes = "application/json")
    public BaseResponseDto update(@RequestBody @Valid MemberPayloadDto dto) {
        return csidService.get("UPDATE_MEMBER").execute(dto);
    }

    @PatchMapping(produces = "application/xml", consumes = "application/json")
    public BaseResponseDto patch(@RequestBody @Valid MemberPayloadDto dto) {
        return csidService.get("PATCH_MEMBER").execute(dto);
    }

    @DeleteMapping(produces = "application/json", consumes = "application/json")
    public BaseResponseDto delete(@RequestBody @Valid MemberPayloadDto dto) {
        return csidService.get("DELETE_MEMBER").execute(dto);
    }
}
