package com.serasaconsumidor.antifraude.csid.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@Data
@XmlRootElement(name = "STLTRANSACTIONINFO")
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@AllArgsConstructor
@NoArgsConstructor
public class TransactionInfoDto {

    @JacksonXmlProperty(localName = "USERID")
    String userId;
    @JacksonXmlProperty(localName = "PASSWORD")
    String password;
    @JacksonXmlProperty(localName = "SERVICECODE")
    String serviceCode;
    @JacksonXmlProperty(localName = "VERSION")
    Double version;
    @JacksonXmlProperty(localName = "STLTRANSACTIONID")
    String transactionId;
}
