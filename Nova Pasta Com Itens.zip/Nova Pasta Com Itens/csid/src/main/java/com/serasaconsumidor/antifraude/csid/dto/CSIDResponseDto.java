package com.serasaconsumidor.antifraude.csid.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CSIDResponseDto {

    @JsonProperty(value = "info")
    @JacksonXmlProperty(localName = "STLTRANSACTIONINFO")
    TransactionInfoResponseDto info;

    @JsonProperty(value = "data")
    @JacksonXmlProperty(localName = "STLTRANSACTIONDATA")
    TransactionDataResponseDto data;
}
