package com.serasaconsumidor.antifraude.csid.dto;

import lombok.Builder;
import lombok.Data;

import javax.xml.bind.annotation.XmlRootElement;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@Data
@XmlRootElement(name = "STLTRANSACTIONINFO")
@Builder
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class TransactionDataDto {

    @JacksonXmlProperty(localName = "USERID")
    String userId;
    @JacksonXmlProperty(localName = "PASSWORD")
    String password;
    @JacksonXmlProperty(localName = "SERVICECODE")
    String serviceCode;
    @JacksonXmlProperty(localName = "VERSION")
    String version;
    @JacksonXmlProperty(localName = "STLTRANSACTIONID")
    String transactionId;
}
