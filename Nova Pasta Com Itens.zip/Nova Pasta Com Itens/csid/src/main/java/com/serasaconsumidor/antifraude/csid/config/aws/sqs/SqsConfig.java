package com.serasaconsumidor.antifraude.csid.config.aws.sqs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jms.annotation.EnableJms;
import org.springframework.jms.config.DefaultJmsListenerContainerFactory;
import org.springframework.jms.config.JmsListenerContainerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.listener.DefaultMessageListenerContainer;
import org.springframework.jms.support.destination.DynamicDestinationResolver;

import javax.jms.Session;

import com.amazon.sqs.javamessaging.ProviderConfiguration;
import com.amazon.sqs.javamessaging.SQSConnectionFactory;
import com.amazonaws.services.sqs.AmazonSQS;
import com.amazonaws.services.sqs.AmazonSQSAsyncClientBuilder;

@EnableJms
@Configuration
public class SqsConfig {

    private static final int NUMBER_OF_MESSAGES_TO_PREFETCH=5;

    @Bean
    public AmazonSQS amazonSqs(final SqsProperties sqsProperties) {
        return AmazonSQSAsyncClientBuilder.standard()
                .withRegion(sqsProperties.getRegion())
                .build();
    }

    @Bean
    public SQSConnectionFactory sqsConnectionFactory(final ProviderConfiguration providerConfiguration, final AmazonSQS amazonSQS) {
        return new SQSConnectionFactory(providerConfiguration, amazonSQS);
    }

    @Bean
    public ProviderConfiguration providerConfiguration() {
        final ProviderConfiguration providerConfiguration = new ProviderConfiguration();
        providerConfiguration.setNumberOfMessagesToPrefetch(NUMBER_OF_MESSAGES_TO_PREFETCH);
        return providerConfiguration;
    }

    @Bean
    public JmsListenerContainerFactory<DefaultMessageListenerContainer> jmsListenerContainerFactory(final SQSConnectionFactory sqsConnectionFactory, final SqsProperties sqsProperties) {
        final DefaultJmsListenerContainerFactory factory = new DefaultJmsListenerContainerFactory();
        factory.setConnectionFactory(sqsConnectionFactory);
        factory.setDestinationResolver(new DynamicDestinationResolver());
        factory.setConcurrency(sqsProperties.getConcurrency());
        factory.setSessionAcknowledgeMode(Session.CLIENT_ACKNOWLEDGE);
        factory.setAutoStartup(true);
        return factory;
    }

    @Bean
    public JmsTemplate defaultJmsTemplate(final SQSConnectionFactory sqsConnectionFactory) {
        return new JmsTemplate(sqsConnectionFactory);
    }
}
