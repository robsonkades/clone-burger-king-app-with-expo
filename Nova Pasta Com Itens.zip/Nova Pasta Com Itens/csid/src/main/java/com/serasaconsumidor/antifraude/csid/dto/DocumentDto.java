package com.serasaconsumidor.antifraude.csid.dto;

import lombok.Builder;
import lombok.Data;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@Data
@Builder
public class DocumentDto {

    @JacksonXmlProperty(localName = "IDNATID")
    private String document;

    @JacksonXmlProperty(localName = "IDNATCOUNTRY")
    private String country;
}
