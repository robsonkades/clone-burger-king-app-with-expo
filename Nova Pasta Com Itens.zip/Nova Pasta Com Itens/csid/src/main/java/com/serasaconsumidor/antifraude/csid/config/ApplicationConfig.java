package com.serasaconsumidor.antifraude.csid.config;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "spring.application")
public class ApplicationConfig {
    private String name;
    private String client;
    private String description;
    private String version;
}
