package com.serasaconsumidor.antifraude.csid.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlElementWrapper;
import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

import java.util.Set;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class MemberPayloadDto {

    @JacksonXmlProperty(localName = "IDPARTNERNUMBER")
    @NotNull
    private Integer partnerId = 125;

    @JacksonXmlProperty(localName = "IDMEMBERID")
    @NotBlank
    private String memberId;

    @JacksonXmlProperty(localName = "IDFNAME")
    private String firstName;

    @JacksonXmlProperty(localName = "IDLNAME")
    private String lastName;

    @JacksonXmlProperty(localName = "IDMNAME")
    private String middleName;

    @JacksonXmlProperty(localName = "IDDOB")
    private String dateOfBirth;

    @JacksonXmlProperty(localName = "IDADD1")
    private String address;

    @JacksonXmlProperty(localName = "IDADD2")
    private String additionalAddress;

    @JacksonXmlProperty(localName = "IDCITY")
    private String city;

    @JacksonXmlProperty(localName = "IDSTATE")
    private String state;

    @JacksonXmlProperty(localName = "IDZIP")
    private String zip;

    @JacksonXmlProperty(localName = "IDCOUNTRYCODE")
    private String countryCode;

    @JacksonXmlProperty(localName = "IDDEFAULTLANG")
    private String defaultLang;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDCCN")
    private Set<String> creditCard;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDRETAILCARD")
    private Set<String> retailCreditCard;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDSSN")
    private Set<String> ssnId;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDSSNHASH")
    private Set<String> ssnHash;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDIBAN")
    private Set<String> creditCardNumberInternational;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDMEDICALID")
    private Set<String> medicalIds;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDHOMEPHONE")
    private Set<String> homePhones;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDWORKPHONE")
    private Set<String> workPhones;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDCELLPHONE")
    private Set<String> phones;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDEMAILADDR")
    private Set<String> emails;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDPASSPORTNUM")
    private Set<String> passports;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDNATIONAL")
    private Set<DocumentDto> documents;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDBANK")
    private Set<BankDto> banks;

    @JacksonXmlElementWrapper(useWrapping = false)
    @JacksonXmlProperty(localName = "IDGEOCODE")
    private Set<GeoCodeDto> geoCodes;

}
