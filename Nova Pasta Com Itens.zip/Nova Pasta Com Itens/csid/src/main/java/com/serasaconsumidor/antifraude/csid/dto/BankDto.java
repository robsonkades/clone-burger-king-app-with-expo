package com.serasaconsumidor.antifraude.csid.dto;

import lombok.Builder;
import lombok.Data;

import com.fasterxml.jackson.dataformat.xml.annotation.JacksonXmlProperty;

@Data
@Builder
public class BankDto {

    @JacksonXmlProperty(localName = "IDBANKACCT")
    private String account;

    @JacksonXmlProperty(localName = "IDBANKROUTE")
    private String bankRoute;
}
