package com.serasaconsumidor.antifraude.csid.config.client;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

import com.serasaconsumidor.antifraude.csid.config.CSIDConfig;

public class BaseClient {

    @Autowired
    protected RestTemplate restTemplate;

    @Autowired
    protected CSIDConfig csidConfig;
}
