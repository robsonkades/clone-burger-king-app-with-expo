package com.serasaconsumidor.antifraude.csid.service.impl;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.stereotype.Service;

import java.util.UUID;

import com.serasaconsumidor.antifraude.csid.config.CSIDConfig;
import com.serasaconsumidor.antifraude.csid.config.client.CSIDClient;
import com.serasaconsumidor.antifraude.csid.dto.BaseResponseDto;
import com.serasaconsumidor.antifraude.csid.dto.IdentityPayloadDto;
import com.serasaconsumidor.antifraude.csid.dto.MemberPayloadDto;
import com.serasaconsumidor.antifraude.csid.dto.TransactionDto;
import com.serasaconsumidor.antifraude.csid.dto.TransactionInfoDto;
import com.serasaconsumidor.antifraude.csid.service.CSIDService;

@Service(value = "CREATE_MEMBER")
@AllArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class CreateMemberServiceImpl implements CSIDService {

    CSIDClient csidClient;
    CSIDConfig csidConfig;

    @Override
    public BaseResponseDto execute(MemberPayloadDto dto) {

        var response =  TransactionInfoDto
                .builder()
                .userId(csidConfig.getUsername())
                .password(csidConfig.getPassword())
                .serviceCode("500")
                .transactionId(UUID.randomUUID().toString())
                .version(null)
                .build();

        var payload = TransactionDto.builder()
                .data(IdentityPayloadDto
                        .builder()
                        .identity(dto)
                        .build())
                .info(response).build();

        return csidClient.execute(payload);
    }
}
