package com.serasaconsumidor.antifraude.csid.controller.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.server.ResponseStatusException;

public class InternalServerErrorException extends ResponseStatusException {

    public InternalServerErrorException(HttpStatus statusCode, String error) {
        super(statusCode, error);
    }
}
