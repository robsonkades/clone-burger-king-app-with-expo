package com.serasaconsumidor.antifraude.csid.listener.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.Map;

import com.serasaconsumidor.antifraude.csid.listener.SqsMessageListener;

@Slf4j
@Service
@RequiredArgsConstructor
public class SqsMessageListenerImpl implements SqsMessageListener {

    @Override
    @JmsListener(destination = "${aws.sqs.csid}")
    public void messageConsumer(@Payload String message, @Headers Map<String, Object> headers) {

    }
}
