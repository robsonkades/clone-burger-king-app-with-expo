package com.serasaconsumidor.antifraude.csid.controller.exception;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@ControllerAdvice
@AllArgsConstructor
@Slf4j
public class ExceptionAdviceHandler extends ResponseEntityExceptionHandler {

    private final MessageSource messageSource;

    @ExceptionHandler(value = {BadRequestException.class})
    protected ResponseEntity<Object> handleBadRequest(ResponseStatusException ex, WebRequest request) {
        ErrorType errorType = ErrorType.INVALID_DATA;
        ApiError apiError = createErrorBuilder(ex.getStatus(), errorType, ex.getReason()).build();
        var req =  ((ServletWebRequest) request).getRequest();
        logger.warn(String.format("%s %s with response: %s", req.getMethod(), req.getRequestURI(), ex.getReason()));
        return handleExceptionInternal(ex, apiError, new HttpHeaders(), ex.getStatus(), request);
    }

    @Override
    protected ResponseEntity<Object> handleNoHandlerFoundException(NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ErrorType errorType = ErrorType.RESOURCE_NOT_FOUND;
        String message = String.format("The resource %s, doesn't found", ex.getRequestURL());
        ApiError apiError = createErrorBuilder(status, errorType, message).build();
        var req =  ((ServletWebRequest) request).getRequest();
        logger.warn(String.format("%s %s with response: %s", req.getMethod(), req.getRequestURI(), message));
        return handleExceptionInternal(ex, apiError, new HttpHeaders(), HttpStatus.NOT_FOUND, request);
    }

    @ExceptionHandler({InternalServerErrorException.class, Exception.class})
    public ResponseEntity<Object> handleUncaught(Exception ex, WebRequest request) {
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        ErrorType errorType = ErrorType.INTERNAL_ERROR;
        String message = ex.getMessage() == null ? "An internal error has occurred" : ex.getMessage();
        logger.error(message, ex);
        ApiError apiError = createErrorBuilder(status, errorType, message).build();

        var req =  ((ServletWebRequest) request).getRequest();
        logger.warn(String.format("%s %s with response: %s", req.getMethod(), req.getRequestURI(), message));

        return handleExceptionInternal(ex, apiError, new HttpHeaders(), status, request);
    }

    @Override
    protected ResponseEntity<Object> handleMethodArgumentNotValid(MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
        ErrorType errorType = ErrorType.INVALID_DATA;
        String message = "One or more fields are invalid";
        BindingResult bindingResult = ex.getBindingResult();

        List<ApiError.Field> errorFields = bindingResult.getFieldErrors().stream()
                .map(fieldError -> {
                    String str = messageSource.getMessage(fieldError, LocaleContextHolder.getLocale());

                    return ApiError.Field.builder().name(fieldError.getField()).message(str).build();
                })
                .collect(Collectors.toList());

        ApiError apiError = createErrorBuilder(status, errorType, message).fields(errorFields).build();

        return handleExceptionInternal(ex, apiError, new HttpHeaders(), HttpStatus.BAD_REQUEST, request);
    }

    private ApiError.ApiErrorBuilder createErrorBuilder(HttpStatus status, ErrorType errorType, String message) {
        return ApiError.builder()
                .timestamp(LocalDateTime.now())
                .status(status.value())
                .type(errorType.getUri())
                .title(errorType.getTitle())
                .message(message);
    }
}
