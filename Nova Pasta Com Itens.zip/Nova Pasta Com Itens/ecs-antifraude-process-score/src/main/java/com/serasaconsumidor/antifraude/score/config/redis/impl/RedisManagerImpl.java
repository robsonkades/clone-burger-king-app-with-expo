package com.serasaconsumidor.antifraude.score.config.redis.impl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Optional;
import java.util.concurrent.TimeUnit;

import com.serasaconsumidor.antifraude.score.config.redis.RedisManager;
import com.serasaconsumidor.antifraude.score.config.security.impl.CryptoSymmetricImpl;

@Component
@Slf4j
@AllArgsConstructor
public class RedisManagerImpl implements RedisManager {

    private final ObjectMapper mapper;
    private final StringRedisTemplate redisTemplate;
    private final CryptoSymmetricImpl cryptoSymmetric;

    @Override
    @Async
    public Boolean setValue(String key, Object value, long expire) {
        try {
            String jsonObject = mapper.writeValueAsString(value);
            redisTemplate.opsForValue().set(key, jsonObject);
            redisTemplate.expire(key, expire, TimeUnit.MINUTES);
            log.info("success to add object of key {}", key);
            return true;
        } catch (Exception e) {
            log.error("unable to add object of key {}: {}", key, e.getMessage());
            return false;
        }
    }

    @Override
    @Async
    public Boolean setValueEncrypt(String key, Object value, long expire) {
        try {
            String jsonObject = mapper.writeValueAsString(value);
            redisTemplate.opsForValue().set(key, cryptoSymmetric.encrypt(jsonObject));
            redisTemplate.expire(key, expire, TimeUnit.MINUTES);
            return true;
        } catch (Exception e) {
            log.error("unable to add object of key {}: {}", key, e.getMessage());
            return false;
        }
    }

    @Override
    public Boolean hasKey(String key) {
        return redisTemplate.hasKey(key);
    }

    @Override
    public <T> Optional<T> findValue(String key, Class<T> classToMap) {
        try {
            String jsonObject = redisTemplate.opsForValue().get(key);
            if (jsonObject == null) {
                log.warn("key '{}' does not exist in cache", key);
                return Optional.empty();
            }
            return Optional.ofNullable(mapper.readValue(jsonObject, classToMap));
        } catch (Exception e) {
            log.error("unable to find entry '{}' in cache: {}", key, e.getMessage());
            return Optional.empty();
        }
    }

    @Override
    public <T> Optional<T> findValueDecrypt(String key, Class<T> classToMap) {
        try {
            String jsonObject = redisTemplate.opsForValue().get(key);
            if (jsonObject == null) {
                log.warn("key '{}' does not exist in cache", key);
                return Optional.empty();
            }
            return Optional.ofNullable(mapper.readValue(cryptoSymmetric.decrypt(jsonObject), classToMap));
        } catch (Exception e) {
            log.error("unable to find entry '{}' in cache: {}", key, e.getMessage());
            return Optional.empty();
        }
    }

    @Override
    @Async
    public Boolean delete(String key) {
        try {
            redisTemplate.delete(key);
            log.info("success to delete object of key {}", key);
            return true;
        } catch (Exception e) {
            log.error("unable to delete object of key {}: {}", key, e.getMessage());
            return false;
        }
    }

    @Override
    public Boolean isAvailable() {
        try {
            return redisTemplate.getConnectionFactory().getConnection().ping() != null;
        } catch (Exception e) {
            log.warn("redis server is not available at the moment.");
        }
        return false;
    }
}