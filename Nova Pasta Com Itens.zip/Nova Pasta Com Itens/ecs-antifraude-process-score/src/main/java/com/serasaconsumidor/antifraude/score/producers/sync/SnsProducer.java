package com.serasaconsumidor.antifraude.score.producers.sync;


public interface SnsProducer {
    void sendMessage(final Object messageEventSendDto, final String topicArn, final String eventType);
}
