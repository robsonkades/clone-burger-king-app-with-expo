package com.serasaconsumidor.antifraude.score.dtos.lgpd.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum OriginMode {
    ONLINE("Online"),
    BATCH("Batch");
    private String description;
}
