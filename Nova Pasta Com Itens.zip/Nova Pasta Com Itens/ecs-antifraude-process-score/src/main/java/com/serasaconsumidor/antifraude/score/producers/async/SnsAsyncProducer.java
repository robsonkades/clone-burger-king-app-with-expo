package com.serasaconsumidor.antifraude.score.producers.async;

public interface SnsAsyncProducer {
    void sendMessage(final Object messageEventSendDto, final String topicArn, final String eventType);
}
