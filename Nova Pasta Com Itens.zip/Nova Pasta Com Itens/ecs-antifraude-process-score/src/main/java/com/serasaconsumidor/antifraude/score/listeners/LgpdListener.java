package com.serasaconsumidor.antifraude.score.listeners;

import com.serasaconsumidor.antifraude.score.dtos.lgpd.LgpdDto;

public interface LgpdListener {
    void messageConsumer(LgpdDto event);
}
