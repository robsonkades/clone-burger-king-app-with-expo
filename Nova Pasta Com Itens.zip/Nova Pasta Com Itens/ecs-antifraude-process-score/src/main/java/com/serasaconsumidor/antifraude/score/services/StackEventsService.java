package com.serasaconsumidor.antifraude.score.services;

import com.serasaconsumidor.antifraude.score.dtos.score.ScoreBatchDto;
import com.serasaconsumidor.antifraude.score.dtos.subscription.SubscriptionDto;

import java.math.BigInteger;

public interface StackEventsService {
    void sendMessage(final SubscriptionDto subscriptionDto, final String eventCode, final BigInteger score, final BigInteger variance);
    void sendMessage(final ScoreBatchDto scoreBatchDto, final String eventCode);
}
