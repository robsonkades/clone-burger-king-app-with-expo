package com.serasaconsumidor.antifraude.score.dtos.lgpd.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum OriginType {
    INPUT("Entrada"),
    OUTPUT("Saída");
    private String description;
}
