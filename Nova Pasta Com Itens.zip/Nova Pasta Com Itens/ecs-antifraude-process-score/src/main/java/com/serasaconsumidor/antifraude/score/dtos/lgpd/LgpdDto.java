package com.serasaconsumidor.antifraude.score.dtos.lgpd;

import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder
public class LgpdDto {
    private String subscriptionCode;
    private String userId;
    private String personDocumentValue;
    private String consultType;
    private String useType;
    private List<String> purposes;
    private OriginDto origin;
    private CompanyDto company;
    private String fieldsToLgpd;
}
