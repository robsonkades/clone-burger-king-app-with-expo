package com.serasaconsumidor.antifraude.score.utils;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;

import java.io.IOException;
import java.time.LocalDate;

public class CustomOffsetLocalDateDeserializer extends JsonDeserializer<LocalDate> {

    public CustomOffsetLocalDateDeserializer() {}

    @Override
    public LocalDate deserialize(JsonParser parser, DeserializationContext context) throws IOException, JsonProcessingException {
        return LocalDate.parse(parser.getText());
    }
}
