package com.serasaconsumidor.antifraude.score.producers.sync.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.amazonaws.services.sns.AmazonSNS;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.Map;

import com.serasaconsumidor.antifraude.score.dtos.common.MessageEventDto;
import com.serasaconsumidor.antifraude.score.exceptions.DefaultException;
import com.serasaconsumidor.antifraude.score.producers.sync.SnsProducer;
import com.serasaconsumidor.antifraude.score.utils.Constants;

import static com.serasaconsumidor.antifraude.score.config.http.HeadersEnum.X_EVENT_TYPE;

@Service
@RequiredArgsConstructor
@Slf4j
public class SnsProducerImpl implements SnsProducer {

    private final AmazonSNS amazonSNS;

    @Override
    public void sendMessage(final Object messageEventSendDto, final String topicArn, final String eventType) {
        try {
            log.info("Building the message to send by sync method");
            Map<String, MessageAttributeValue> attributes = new HashMap<>();
            attributes.put(X_EVENT_TYPE.getKey(), new MessageAttributeValue()
                    .withDataType(Constants.STRING_DATA_TYPE)
                    .withStringValue(eventType));

            MessageEventDto messageDto = MessageEventDto.builder()
                    .data(messageEventSendDto)
                    .build();

            String messageAsJson = new ObjectMapper().writeValueAsString(messageDto);

            PublishRequest publishRequest = new PublishRequest()
                    .withMessageAttributes(attributes)
                    .withTopicArn(topicArn)
                    .withMessage(messageAsJson);

            final String messageId = amazonSNS.publish(publishRequest).getMessageId();
            log.info("The message was send to SNS with message id: {}", messageId);
        } catch (Exception e) {
            throw new DefaultException(HttpStatus.BAD_REQUEST, "error communicating with Amazon SNS API: " + e.getMessage());
        }
    }
}
