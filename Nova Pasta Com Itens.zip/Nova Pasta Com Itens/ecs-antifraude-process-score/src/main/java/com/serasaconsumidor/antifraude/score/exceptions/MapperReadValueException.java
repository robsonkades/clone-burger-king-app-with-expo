package com.serasaconsumidor.antifraude.score.exceptions;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

@Getter
@Setter
public class MapperReadValueException extends RuntimeException {

    private final HttpStatus statusCode;
    private final String error;

    public MapperReadValueException(HttpStatus statusCode, String error) {
        super(error);
        this.statusCode = statusCode;
        this.error = error;
    }
}
