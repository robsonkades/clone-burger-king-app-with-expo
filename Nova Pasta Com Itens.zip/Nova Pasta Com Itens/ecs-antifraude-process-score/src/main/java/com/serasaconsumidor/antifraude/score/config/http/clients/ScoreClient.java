package com.serasaconsumidor.antifraude.score.config.http.clients;

import java.util.List;
import java.util.Optional;

import com.serasaconsumidor.antifraude.score.dtos.score.ScoreNumberDto;
import com.serasaconsumidor.antifraude.score.dtos.score.RequestScoreDto;
import com.serasaconsumidor.antifraude.score.dtos.score.ResponseScoreHistoryDto;
import com.serasaconsumidor.antifraude.score.dtos.score.ScoreBatchDto;

public interface ScoreClient {
    Optional<List<ResponseScoreHistoryDto>> listHistory(RequestScoreDto requestScoreTimelineDto, ScoreClientIdEnum scoreClientId);
    Optional<ScoreNumberDto> getScore(ScoreBatchDto requestScoreDto, ScoreClientIdEnum scoreClientId);
}
