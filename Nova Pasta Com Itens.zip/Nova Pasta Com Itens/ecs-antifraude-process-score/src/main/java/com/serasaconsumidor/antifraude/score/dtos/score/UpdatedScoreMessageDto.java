package com.serasaconsumidor.antifraude.score.dtos.score;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.serasaconsumidor.antifraude.score.exceptions.MapperReadValueException;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class UpdatedScoreMessageDto {

    private UpdatedScoreDto data;

    public static UpdatedScoreMessageDto fromJSON(String json) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(json, UpdatedScoreMessageDto.class);
        } catch (Exception exc) {
            throw new MapperReadValueException(HttpStatus.INTERNAL_SERVER_ERROR, exc.getMessage());
        }
    }
}
