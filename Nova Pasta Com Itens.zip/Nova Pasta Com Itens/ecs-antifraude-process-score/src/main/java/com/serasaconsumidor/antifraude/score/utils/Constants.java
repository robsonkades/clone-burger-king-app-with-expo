package com.serasaconsumidor.antifraude.score.utils;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Constants {

    private static final String CACHE_KEY = "score:score-monitoring:%s";

    public static final String SNS_EVENT_DELIVERY_FILTER = "event-delivery";
    public static final String SNS_LGPD_FILTER_POLICY = "lgpd";
    public static final String STRING_DATA_TYPE = "String";
    public static final String NATURAL_PERSON = "PF";
    public static final String STACK_EVENTS_SNS_FILTER = "generate-event";
    public static final int SCORE_VARIANCE_NOTIFICATION = 30;
    public static final int CACHE_EXPIRATION_SCORE_MONITORING = 1440; // 24 Horas em minutos

    //LGPD
    public static final Integer DEFAULT_ORIGIN_ID = 19;

    public static String getScoreMonitoringCacheKey(String subscriptionCode) {
        return String.format(CACHE_KEY, subscriptionCode);
    }
}
