package com.serasaconsumidor.antifraude.score.services.impl;

import com.serasaconsumidor.antifraude.score.config.sns.SnsProperties;
import com.serasaconsumidor.antifraude.score.dtos.delivery.MessageAlertDto;
import com.serasaconsumidor.antifraude.score.dtos.delivery.ScoreAlertDto;
import com.serasaconsumidor.antifraude.score.dtos.score.ResponseScoreHistoryDto;
import com.serasaconsumidor.antifraude.score.dtos.subscription.SubscriptionDto;
import com.serasaconsumidor.antifraude.score.producers.sync.SnsProducer;
import com.serasaconsumidor.antifraude.score.services.CreateScoreAlertService;
import com.serasaconsumidor.antifraude.score.services.StackEventsService;
import com.serasaconsumidor.antifraude.score.utils.Constants;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.Date;

import static com.serasaconsumidor.antifraude.score.config.Events.SCORE_EVENT;
import static com.serasaconsumidor.antifraude.score.config.Events.SCORE_WITH_VARIATION;

@Service
@AllArgsConstructor
@Slf4j
public class CreateScoreAlertServiceImpl implements CreateScoreAlertService {

    private final SnsProducer snsProducer;
    private final SnsProperties snsProperties;
    private final StackEventsService stackEventsService;

    @Override
    public void execute(SubscriptionDto subscription, ResponseScoreHistoryDto scoreHistoryDto, boolean newScore) {

        log.info("Process to userId {}: previous score {}, current score {}, variance {}", subscription.getUserId(), scoreHistoryDto.previousScore(), scoreHistoryDto.getScore(), scoreHistoryDto.getVarianceAbsolute());

        stackEventsService.sendMessage(subscription, SCORE_EVENT, BigInteger.ZERO, BigInteger.ZERO);

        log.info("Score with variation to userId {}, variance {}", subscription.getUserId(), scoreHistoryDto.getVariance());

        var payload = MessageAlertDto.builder()
                .subscriptionCode(subscription.getSubscriptionCode())
                .typeEvent("score-alert")
                .parameters(ScoreAlertDto.builder()
                        .generationDate(new Date())
                        .score(scoreHistoryDto.getScore().longValue())
                        .message(scoreHistoryDto.getMessage())
                        .hasIncreased(scoreHistoryDto.hasIncrease())
                        .newScore(newScore)
                        .build())
                .build();

        log.info("Send score alert to userId {}", subscription.getUserId());

        snsProducer.sendMessage(payload, snsProperties.getTopicArnEvents(), Constants.SNS_EVENT_DELIVERY_FILTER);
        stackEventsService.sendMessage(subscription, SCORE_WITH_VARIATION, scoreHistoryDto.getScore().toBigInteger(), scoreHistoryDto.getVariance().toBigInteger());
    }
}
