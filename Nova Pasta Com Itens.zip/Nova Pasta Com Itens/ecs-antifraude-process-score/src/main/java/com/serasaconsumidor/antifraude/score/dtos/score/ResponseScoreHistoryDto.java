package com.serasaconsumidor.antifraude.score.dtos.score;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.serasaconsumidor.antifraude.score.utils.DateTimeUtils;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.time.LocalDate;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ResponseScoreHistoryDto {
    private long score;
    private long variance;
    private String date;
    private ScoreMessageDto message;
    private String model;

    public LocalDate getLocalDate() {
        return DateTimeUtils.dateFormatterToLocalDate(this.date);
    }

    public boolean hasIncrease() {
        return this.getVariance().signum() == 1;
    }

    public BigDecimal getVarianceAbsolute() {
        return this.getVariance().abs();
    }

    public BigDecimal getVariance() {
        return BigDecimal.valueOf(this.variance);
    }

    public BigDecimal getScore() {
        return BigDecimal.valueOf(this.score);
    }

    public BigDecimal previousScore() {
        return this.hasIncrease() ?
                this.getScore().subtract(this.getVarianceAbsolute()) :
                this.getScore().add(this.getVarianceAbsolute());
    }
}