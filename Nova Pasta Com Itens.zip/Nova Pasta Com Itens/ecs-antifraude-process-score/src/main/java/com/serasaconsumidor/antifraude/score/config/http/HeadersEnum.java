package com.serasaconsumidor.antifraude.score.config.http;

public enum HeadersEnum {

    X_REQUEST_ID("X-Request-Id", "X-Request-Id"),
    X_CONSUMER_ID("X-Consumer-Id", "X-Consumer-Id"),
    X_BISFROST_AUTHORIZATION("X-Bifrost-Authorization", "X-Bifrost-Authorization"),
    X_CONSUMER_DOCUMENT("X-Consumer-Document", "X-Consumer-Document"),
    X_CLIENT("X-Client", "X-Client"),
    X_APPLICATION("X-Application", "X-Application"),
    X_SUBSCRIPTION_CODE("X-Subscription-Code", "X-Subscription-Code"),
    X_EVENT_TYPE("X-Event-Type", "X-Event-Type"),
    X_FEATURE_GROUPS("X-Feature-Groups", "X-Feature-Groups"),

    METHOD("method", "method"),
    PATH("path", "path"),
    X_FORWARDED_FOR("X-Forwarded-For", "X-Forwarded-For"),
    USER_AGENT("User-Agent", "User-Agent"),
    ORIGIN("origin", "origin"),
    REFERER("referer", "referer");


    private final String key;
    private final String value;

    HeadersEnum(String k, String v) {
        key = k;
        value = v;
    }

    public String getValue() {
        return value;
    }

    public String getKey() {
        return key;
    }
}
