package com.serasaconsumidor.antifraude.score.dtos.stackevents.data.saf;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigInteger;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class SafDto {
    private String subscriptionCode;
    private String userId;
    private BigInteger score;
    private BigInteger variance;
}
