package com.serasaconsumidor.antifraude.score.config.mapper.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

import com.serasaconsumidor.antifraude.score.config.mapper.LgpdMapper;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.CompanyDto;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.LgpdDto;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.OriginDto;
import com.serasaconsumidor.antifraude.score.dtos.subscription.SubscriptionDto;

@Slf4j
@Component
public class LgpdMapperImpl implements LgpdMapper {

    @Override
    public LgpdDto convert(SubscriptionDto subscriptionDto, Object fields, String consultType, String useType, String purposes, OriginDto origin, CompanyDto company) {
        String fieldsToLgpd = null;

        if (fields != null) {
            try {
                fieldsToLgpd = new ObjectMapper().writeValueAsString(fields);
            } catch (JsonProcessingException ex) {
                log.error("Fails to try to build JSON with LGPD log fields");
            }
        } else {
            fieldsToLgpd = "";
        }

        return LgpdDto.builder()
                .subscriptionCode(subscriptionDto.getSubscriptionCode())
                .userId(subscriptionDto.getUserId().toString())
                .personDocumentValue(subscriptionDto.getDocument())
                .consultType(consultType)
                .useType(useType)
                .purposes(List.of(purposes))
                .origin(origin)
                .company(company)
                .fieldsToLgpd(fieldsToLgpd)
                .build();
    }
}
