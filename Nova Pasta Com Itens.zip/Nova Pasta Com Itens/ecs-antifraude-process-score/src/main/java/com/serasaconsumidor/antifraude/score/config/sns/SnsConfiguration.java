package com.serasaconsumidor.antifraude.score.config.sns;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

import com.amazonaws.regions.RegionUtils;
import com.amazonaws.services.sns.AmazonSNSAsync;
import com.amazonaws.services.sns.AmazonSNSAsyncClientBuilder;

@Configuration
public class SnsConfiguration {

    @Bean
    @Primary
    public AmazonSNSAsync ssnClient(SnsProperties snsProperties) {
        return AmazonSNSAsyncClientBuilder.standard()
                .withRegion(String.valueOf(RegionUtils.getRegion(snsProperties.getRegion())))
                .build();
    }
}

