package com.serasaconsumidor.antifraude.score.exceptions;

import org.zalando.problem.AbstractThrowableProblem;
import org.zalando.problem.Status;

import java.net.URI;

public class SqsConsumerException extends AbstractThrowableProblem {

    private static final URI TYPE = URI.create("https://example.org/bad-request");

    public SqsConsumerException(String message) {

        super(TYPE, "sqsConsumerException", Status.BAD_REQUEST, message);
    }

}
