package com.serasaconsumidor.antifraude.score.services.impl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigInteger;

import com.serasaconsumidor.antifraude.score.config.ApplicationProperties;
import com.serasaconsumidor.antifraude.score.config.sns.SnsProperties;
import com.serasaconsumidor.antifraude.score.dtos.score.ScoreBatchDto;
import com.serasaconsumidor.antifraude.score.dtos.stackevents.StackEventDto;
import com.serasaconsumidor.antifraude.score.dtos.stackevents.data.DataDto;
import com.serasaconsumidor.antifraude.score.dtos.stackevents.data.saf.SafDto;
import com.serasaconsumidor.antifraude.score.dtos.subscription.SubscriptionDto;
import com.serasaconsumidor.antifraude.score.producers.async.SnsAsyncProducer;
import com.serasaconsumidor.antifraude.score.services.StackEventsService;
import com.serasaconsumidor.antifraude.score.utils.Constants;

@Service
@AllArgsConstructor
@Slf4j
public class StackEventsServiceImpl implements StackEventsService {

    private final ApplicationProperties applicationProperties;
    private final SnsProperties snsProperties;
    private final SnsAsyncProducer asyncProducer;

    @Override
    public void sendMessage(SubscriptionDto subscriptionDto, String eventCode, BigInteger score, BigInteger variance) {
        log.info("Building object to send to stack events");
        final SafDto safDto = SafDto
                .builder()
                .subscriptionCode(subscriptionDto.getSubscriptionCode())
                .userId(subscriptionDto.getUserId().toString())
                .score(score)
                .variance(variance)
                .build();

        final StackEventDto stackEventDto = StackEventDto
                .builder()
                .document(subscriptionDto.getDocument())
                .subscriptionCode(subscriptionDto.getSubscriptionCode())
                .userId(subscriptionDto.getUserId().toString())
                .eventCode(eventCode)
                .clientOrigin(applicationProperties.getClient())
                .serviceOrigin(applicationProperties.getName())
                .userType(Constants.NATURAL_PERSON)
                .data(DataDto.builder().saf(safDto).build())
                .build();

        asyncProducer.sendMessage(stackEventDto, snsProperties.getTopicArnStackEvents(), Constants.STACK_EVENTS_SNS_FILTER);
    }

    @Override
    public void sendMessage(ScoreBatchDto scoreBatchDto, String eventCode) {
        final StackEventDto stackEventDto = StackEventDto
                .builder()
                .document(scoreBatchDto.getDocument())
                .userId(scoreBatchDto.getUserId())
                .eventCode(eventCode)
                .clientOrigin(applicationProperties.getClient())
                .serviceOrigin(applicationProperties.getName())
                .userType(Constants.NATURAL_PERSON)
                .build();

        asyncProducer.sendMessage(stackEventDto, snsProperties.getTopicArnStackEvents(), Constants.STACK_EVENTS_SNS_FILTER);
    }
}
