package com.serasaconsumidor.antifraude.score.config.http.context;

import java.util.List;
import java.util.Map;

public interface RequestContext {
    Map<String, List<String>> getHeadersToForward();
}
