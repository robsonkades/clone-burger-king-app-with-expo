package com.serasaconsumidor.antifraude.score.exceptions;

import org.zalando.problem.AbstractThrowableProblem;
import org.zalando.problem.Status;

import java.net.URI;

public class SqsProducerException extends AbstractThrowableProblem {
    private static final URI TYPE = URI.create("https://example.org/bad-request");

    public SqsProducerException(String message) {
        super(TYPE, "sqsProducerException", Status.SERVICE_UNAVAILABLE, message);
    }
}
