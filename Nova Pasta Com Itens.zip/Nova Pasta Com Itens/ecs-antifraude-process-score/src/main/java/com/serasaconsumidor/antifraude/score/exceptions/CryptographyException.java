package com.serasaconsumidor.antifraude.score.exceptions;

import org.zalando.problem.AbstractThrowableProblem;
import org.zalando.problem.Status;

import java.net.URI;

public class CryptographyException extends AbstractThrowableProblem {

    private static final URI TYPE = URI.create("https://evertpot.com/http/500-service-unavailable");

    public CryptographyException(final String message) {
        super(TYPE, "Erro interno", Status.INTERNAL_SERVER_ERROR, message);
    }
}
