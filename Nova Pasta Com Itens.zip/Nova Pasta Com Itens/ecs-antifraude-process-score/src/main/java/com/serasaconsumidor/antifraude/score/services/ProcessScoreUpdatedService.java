package com.serasaconsumidor.antifraude.score.services;

import com.serasaconsumidor.antifraude.score.dtos.score.UpdatedScoreMessageDto;

public interface ProcessScoreUpdatedService {
    void execute(UpdatedScoreMessageDto scoreUpdated);
}
