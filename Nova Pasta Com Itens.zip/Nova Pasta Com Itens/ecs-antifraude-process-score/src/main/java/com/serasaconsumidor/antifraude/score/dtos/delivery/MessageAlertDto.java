package com.serasaconsumidor.antifraude.score.dtos.delivery;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Builder
public class MessageAlertDto {
    private String subscriptionCode;
    private String typeEvent;
    private ScoreAlertDto parameters;
}
