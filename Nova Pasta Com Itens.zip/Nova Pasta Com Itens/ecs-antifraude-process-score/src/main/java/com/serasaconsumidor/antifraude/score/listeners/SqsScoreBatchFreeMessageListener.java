package com.serasaconsumidor.antifraude.score.listeners;

import java.util.Map;

public interface SqsScoreBatchFreeMessageListener {
    void messageConsumer(String message, Map<String, Object> headers);
}
