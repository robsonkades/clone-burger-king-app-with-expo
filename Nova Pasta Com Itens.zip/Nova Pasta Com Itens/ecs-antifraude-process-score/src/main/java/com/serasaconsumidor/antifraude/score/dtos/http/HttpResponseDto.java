package com.serasaconsumidor.antifraude.score.dtos.http;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Builder
public class HttpResponseDto {
    private String message;
    private Object data;
}
