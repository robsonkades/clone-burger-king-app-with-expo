package com.serasaconsumidor.antifraude.score.config.http.filter;

import org.slf4j.MDC;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

import com.serasaconsumidor.antifraude.score.config.http.HeadersEnum;
import com.serasaconsumidor.antifraude.score.utils.UriUtils;

@Component
public class CustomFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse, FilterChain filterChain) throws ServletException, IOException {
        try {
            requestHeaders(httpServletRequest);
            filterChain.doFilter(httpServletRequest, httpServletResponse);
        } finally {
            for (HeadersEnum headersEnum : HeadersEnum.values()) {
                MDC.remove(headersEnum.getKey());
            }
        }
    }

    private void requestHeaders(final HttpServletRequest request) {
        for (HeadersEnum headersEnum : HeadersEnum.values()) {
            MDC.put(headersEnum.getKey(), request.getHeader(headersEnum.getValue()));
        }
        MDC.put("method", request.getMethod());
        MDC.put("path", UriUtils.pathObfuscator(request.getRequestURI()));
    }
}
