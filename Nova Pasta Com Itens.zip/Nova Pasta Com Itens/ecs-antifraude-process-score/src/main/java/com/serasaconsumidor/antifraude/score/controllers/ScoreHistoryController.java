package com.serasaconsumidor.antifraude.score.controllers;

import lombok.AllArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import java.net.URI;
import java.util.List;

import com.serasaconsumidor.antifraude.score.config.http.clients.ScoreClient;
import com.serasaconsumidor.antifraude.score.config.http.clients.ScoreClientIdEnum;
import com.serasaconsumidor.antifraude.score.dtos.score.RequestScoreDto;
import com.serasaconsumidor.antifraude.score.dtos.score.ResponseScoreHistoryDto;

@RestController
@RequestMapping("/v3")
@AllArgsConstructor
public class ScoreHistoryController {

    private final ScoreClient score;

    @CrossOrigin(origins = "*")
    @PostMapping(path = "/history", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ResponseScoreHistoryDto>> index(@RequestBody @Valid RequestScoreDto payload, HttpServletRequest request) {

        var scoreHistory = score.listHistory(payload, ScoreClientIdEnum.PREMIUM_WEB);
        var history = scoreHistory.get();

        String url = ServletUriComponentsBuilder.fromRequestUri(request)
                .replacePath("/af/score/request/v1/history")
                .build()
                .toUriString();

        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(URI.create(url));

        if (!history.isEmpty()) {
            return ResponseEntity.ok()
                    .headers(headers)
                    .body(history);
        }
        return ResponseEntity
                .status(HttpStatus.NO_CONTENT)
                .headers(headers)
                .body(history);
    }
}
