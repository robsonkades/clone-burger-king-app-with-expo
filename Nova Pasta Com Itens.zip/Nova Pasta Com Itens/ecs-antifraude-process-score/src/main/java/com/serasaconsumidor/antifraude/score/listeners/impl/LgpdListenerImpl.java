package com.serasaconsumidor.antifraude.score.listeners.impl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.serasaconsumidor.antifraude.score.config.sns.SnsProperties;
import com.serasaconsumidor.antifraude.score.dtos.common.MessageEventDto;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.LgpdDto;
import com.serasaconsumidor.antifraude.score.listeners.LgpdListener;
import com.serasaconsumidor.antifraude.score.producers.sync.SnsProducer;
import com.serasaconsumidor.antifraude.score.utils.Constants;

@Slf4j
@Component
@AllArgsConstructor
public class LgpdListenerImpl implements LgpdListener {

    private final SnsProducer snsProducer;
    private final SnsProperties snsProperties;

    @Override
    @Async
    @EventListener({ LgpdDto.class })
    public void messageConsumer(LgpdDto event) {
        log.info("Starting LGPD log processing");

        snsProducer.sendMessage(MessageEventDto
                .builder()
                .data(event)
                .build(), snsProperties.getTopicArnLgpd(), Constants.SNS_LGPD_FILTER_POLICY);

        log.info("Terminating LGPD log processing");
    }
}
