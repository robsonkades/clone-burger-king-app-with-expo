package com.serasaconsumidor.antifraude.score.dtos.lgpd.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum Purposes {
    MARKETING("MARKETING"),
    CREDIT("CREDITO"),
    LEVIE("COBRANCA"),
    FRAUD("FRAUDE"),
    REGISTRATION_UPDATE("ATUALIZACAO CADASTRAL"),
    REGULATORY_COMPLIANCE("CUMPRIMENTO DE REGULAMENTACAO"),
    PRICING("PRECIFICACAO");
    private String description;
}
