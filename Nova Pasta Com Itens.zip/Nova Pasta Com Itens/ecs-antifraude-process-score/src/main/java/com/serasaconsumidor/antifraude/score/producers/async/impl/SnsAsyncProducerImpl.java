package com.serasaconsumidor.antifraude.score.producers.async.impl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.amazonaws.services.sns.AmazonSNSAsync;
import com.amazonaws.services.sns.model.MessageAttributeValue;
import com.amazonaws.services.sns.model.PublishRequest;
import com.amazonaws.services.sns.model.PublishResult;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

import com.serasaconsumidor.antifraude.score.config.http.HeadersEnum;
import com.serasaconsumidor.antifraude.score.dtos.common.MessageEventDto;
import com.serasaconsumidor.antifraude.score.producers.async.SnsAsyncProducer;
import com.serasaconsumidor.antifraude.score.utils.Constants;

@Service
@Slf4j
@AllArgsConstructor
public class SnsAsyncProducerImpl implements SnsAsyncProducer {

    private final AmazonSNSAsync amazonSNSAsync;

    @Override
    @Async
    public void sendMessage(final Object messageEventSendDto, final String topicArn, final String eventType) {
        try {
            log.info("Building the message to send by async method");
            Map<String, MessageAttributeValue> attributes = new HashMap<>();
            attributes.put(HeadersEnum.X_EVENT_TYPE.getKey(), new MessageAttributeValue()
                    .withDataType(Constants.STRING_DATA_TYPE)
                    .withStringValue(eventType));

            MessageEventDto messageDto = MessageEventDto.builder()
                    .data(messageEventSendDto)
                    .build();

            String messageAsJson = new ObjectMapper().writeValueAsString(messageDto);

            PublishRequest publishRequest = new PublishRequest()
                    .withMessageAttributes(attributes)
                    .withTopicArn(topicArn)
                    .withMessage(messageAsJson);
            Future<PublishResult> resultFuture = amazonSNSAsync.publishAsync(publishRequest);
            log.info("The async message was send to SNS with message id: {}", resultFuture.get().getMessageId());
        } catch (Exception ex) {
            log.error("Error communicating with Amazon SNS Async API. HttpStatus: {} Error: {}", HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage());
        }
    }
}
