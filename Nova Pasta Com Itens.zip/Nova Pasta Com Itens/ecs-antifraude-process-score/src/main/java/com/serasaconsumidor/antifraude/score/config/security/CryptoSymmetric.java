package com.serasaconsumidor.antifraude.score.config.security;

public interface CryptoSymmetric {
    String encrypt(String string);
    String decrypt(String string);
}