package com.serasaconsumidor.antifraude.score.listeners.impl;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.Map;

import com.serasaconsumidor.antifraude.score.dtos.score.UpdatedScoreMessageDto;
import com.serasaconsumidor.antifraude.score.listeners.SqsMessageListener;
import com.serasaconsumidor.antifraude.score.services.ProcessScoreUpdatedService;

@Slf4j
@Component
@Builder
@AllArgsConstructor
public class SqsMessageListenerImpl implements SqsMessageListener {

    private final ProcessScoreUpdatedService processScoreChangedService;

    @JmsListener(destination = "${aws.sqs.updatedScore}")
    @Override
    public void messageConsumer(@Payload String message, @Headers  Map<String, Object> headers) {
        log.info("Score Updated");

        try {
            UpdatedScoreMessageDto scoreUpdated = UpdatedScoreMessageDto.fromJSON(message);
            processScoreChangedService.execute(scoreUpdated);
        } catch (Exception ex) {
            log.error("An error occurred while processing a message {}", ex);
            throw new RuntimeException(ex);
        }
    }
}


