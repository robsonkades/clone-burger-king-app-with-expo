package com.serasaconsumidor.antifraude.score.dtos.stackevents.data;

import com.serasaconsumidor.antifraude.score.dtos.stackevents.data.saf.SafDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class DataDto {
    private SafDto saf;
}
