package com.serasaconsumidor.antifraude.score.utils;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Component;

import com.serasaconsumidor.antifraude.score.config.mapper.LgpdMapper;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.CompanyDto;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.LgpdDto;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.OriginDto;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.enums.CompanyType;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.enums.ConsultType;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.enums.OriginMode;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.enums.OriginType;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.enums.Purposes;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.enums.UseType;
import com.serasaconsumidor.antifraude.score.dtos.subscription.SubscriptionDto;


@Component
@AllArgsConstructor
public class LgpdBuilder {

    private final LgpdMapper lgpdMapper;

    public LgpdDto constructLgpdDto(SubscriptionDto subscriptionDto, Object fieldsToLgpd) {
        var origin = OriginDto.builder()
                .id(Constants.DEFAULT_ORIGIN_ID)
                .mode(OriginMode.ONLINE.getDescription())
                .type(OriginType.OUTPUT.getDescription())
                .build();

        var company = CompanyDto.builder()
                .id(subscriptionDto.getPartnerId())
                .type(CompanyType.PARTNER.getDescription())
                .build();

        return lgpdMapper.convert(subscriptionDto, fieldsToLgpd, ConsultType.INTERNAL.getDescription(), UseType.CONSUMPTION.getDescription(), Purposes.REGULATORY_COMPLIANCE.getDescription(), origin, company);
    }

}
