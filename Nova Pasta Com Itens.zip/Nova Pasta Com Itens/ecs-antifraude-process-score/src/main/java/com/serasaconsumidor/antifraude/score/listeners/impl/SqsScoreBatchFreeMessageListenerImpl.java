package com.serasaconsumidor.antifraude.score.listeners.impl;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.extern.slf4j.Slf4j;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.messaging.handler.annotation.Headers;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.Map;

import com.serasaconsumidor.antifraude.score.config.http.clients.ScoreClient;
import com.serasaconsumidor.antifraude.score.config.http.clients.ScoreClientIdEnum;
import com.serasaconsumidor.antifraude.score.dtos.score.ScoreBatchMessageDto;
import com.serasaconsumidor.antifraude.score.listeners.SqsScoreBatchFreeMessageListener;
import com.serasaconsumidor.antifraude.score.services.StackEventsService;

import static com.serasaconsumidor.antifraude.score.config.Events.REQUEST_SCORE_FREEMIUM_BATCH;

@Slf4j
@Component
@Builder
@AllArgsConstructor
public class SqsScoreBatchFreeMessageListenerImpl implements SqsScoreBatchFreeMessageListener {

    private final StackEventsService stackEventsService;
    private final ScoreClient scoreClient;

    @JmsListener(destination = "${aws.sqs.processScoreFree}")
    @Override
    public void messageConsumer(@Payload String message, @Headers  Map<String, Object> headers) {
        ScoreBatchMessageDto scoreUpdated = ScoreBatchMessageDto.fromJSON(message);
        scoreClient.getScore(scoreUpdated.getData(), ScoreClientIdEnum.FREEMIUM_BATCH);
        stackEventsService.sendMessage(scoreUpdated.getData(), REQUEST_SCORE_FREEMIUM_BATCH);
    }
}


