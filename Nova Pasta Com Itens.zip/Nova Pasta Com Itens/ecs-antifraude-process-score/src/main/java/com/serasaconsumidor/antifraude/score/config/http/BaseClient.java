package com.serasaconsumidor.antifraude.score.config.http;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.client.RestTemplate;

public class BaseClient {

    @Autowired
    protected ClientProperties clientProperties;

    @Autowired
    protected RestTemplate restTemplate;
}
