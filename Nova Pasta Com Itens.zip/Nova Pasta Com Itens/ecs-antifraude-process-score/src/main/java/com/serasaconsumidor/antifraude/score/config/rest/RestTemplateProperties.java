package com.serasaconsumidor.antifraude.score.config.rest;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Getter
@Setter
@Configuration
@ConfigurationProperties(prefix = "client.defaults")
public class RestTemplateProperties {
    private Long connectTimeout;
    private Long readTimeout;
}