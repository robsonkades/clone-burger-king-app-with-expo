package com.serasaconsumidor.antifraude.score.config.http.clients;

public enum ScoreClientIdEnum {

    PREMIUM_BATCH("premium-batch"),
    FREEMIUM_BATCH("freemium-batch"),
    PREMIUM_WEB("premium-web");

    private final String value;

    ScoreClientIdEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }

    public static ScoreClientIdEnum getKey(String value) {
        ScoreClientIdEnum[] values = ScoreClientIdEnum.values();
        for (int i = 0; i < values.length; i++) {
            if (values[i].getValue() == value) {
                return values[i];
            }
        }
        return null;
    }
}
