package com.serasaconsumidor.antifraude.score.config.http.context.impl;

import lombok.AllArgsConstructor;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.serasaconsumidor.antifraude.score.config.ApplicationProperties;
import com.serasaconsumidor.antifraude.score.config.http.context.RequestContext;

@Service
@AllArgsConstructor
public class RequestContextImpl implements RequestContext {

    private static final List<String> HEADERS_TO_FORWARD = List.of(
            "x-request-id", "x-forwarded-for",
            "user-agent", "origin", "referer",
            "x-consumer-id", "x-consumer-document",
            "x-event-type", "x-feature-groups",
            "x-subscription-id", "method", "path"
    );

    private final HttpServletRequest request;
    private final ApplicationProperties applicationProperties;

    @Override
    public Map<String, List<String>> getHeadersToForward() {
        Map<String, List<String>> headersMap = Collections
                .list(request.getHeaderNames())
                .stream()
                .filter(a -> HEADERS_TO_FORWARD.stream().anyMatch(str -> str.equalsIgnoreCase(a)))
                .collect(Collectors.toMap(
                        Function.identity(),
                        h -> Collections.list(request.getHeaders(h))
                ));

        headersMap.put("X-Client", Collections.singletonList(applicationProperties.getClient()));
        headersMap.put("X-Application", Collections.singletonList(applicationProperties.getName()));

        return headersMap;
    }

}
