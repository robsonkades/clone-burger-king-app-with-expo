package com.serasaconsumidor.antifraude.score.config.sns;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Setter
@Getter
@Component
@ConfigurationProperties(prefix = "aws.sns")
public class SnsProperties {
    private String region;
    private String topicArnEvents;
    private String topicArnLgpd;
    private String topicArnStackEvents;
}
