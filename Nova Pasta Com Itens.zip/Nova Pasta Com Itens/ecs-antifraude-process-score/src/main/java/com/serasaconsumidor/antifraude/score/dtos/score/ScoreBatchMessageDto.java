package com.serasaconsumidor.antifraude.score.dtos.score;

import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.serasaconsumidor.antifraude.score.exceptions.MapperReadValueException;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ScoreBatchMessageDto {

    private ScoreBatchDto data;

    public static ScoreBatchMessageDto fromJSON(String json) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(json, ScoreBatchMessageDto.class);
        } catch (Exception exc) {
            throw new MapperReadValueException(HttpStatus.INTERNAL_SERVER_ERROR, exc.getMessage());
        }
    }
}
