package com.serasaconsumidor.antifraude.score.config.rest;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import java.io.IOException;

import com.serasaconsumidor.antifraude.score.config.ApplicationProperties;
import com.serasaconsumidor.antifraude.score.utils.UriUtils;

@Slf4j
@Component
@AllArgsConstructor
public class RestTemplateInterceptor implements ClientHttpRequestInterceptor {

    private ApplicationProperties applicationProperties;
    private static final String CONTEXT_SERVICE = "contextService";
    private static final String CONTEXT_STATUS_CODE = "contextStatusCode";

    @Override
    public ClientHttpResponse intercept(HttpRequest httpRequest, byte[] body, final ClientHttpRequestExecution clientHttpRequestExecution) throws IOException {
        logRequest(httpRequest, body);
        HttpHeaders httpHeaders = httpRequest.getHeaders();
        MDC.getCopyOfContextMap().forEach(httpHeaders::add);
        httpHeaders.set("X-Client", applicationProperties.getClient());
        httpHeaders.set("X-Application", applicationProperties.getName());
        ClientHttpResponse response = clientHttpRequestExecution.execute(httpRequest, body);
        logResponse(response);
        return response;
    }

    private void logRequest(HttpRequest request, byte[] body){
        MDC.put(CONTEXT_SERVICE, UriUtils.pathObfuscator(request.getURI().getRawPath()));
        log.info("request begin");

    }

    private void logResponse(ClientHttpResponse response) throws IOException {
        MDC.put(CONTEXT_STATUS_CODE, response.getStatusCode().toString());
        log.info("request end");
        MDC.remove(CONTEXT_SERVICE);
        MDC.remove(CONTEXT_STATUS_CODE);
    }

}

