package com.serasaconsumidor.antifraude.score.dtos.common;

import lombok.Builder;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.serasaconsumidor.antifraude.score.exceptions.MapperReadValueException;


@Getter
@Setter
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class MessageEventDto {

    private Object data;

    public static MessageEventDto fromJSON(String json) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(json, MessageEventDto.class);
        } catch (Exception exc) {
            throw new MapperReadValueException(HttpStatus.INTERNAL_SERVER_ERROR, exc.getMessage());
        }
    }
}
