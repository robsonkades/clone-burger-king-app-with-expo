package com.serasaconsumidor.antifraude.score.exceptions;

import org.zalando.problem.AbstractThrowableProblem;
import org.zalando.problem.Status;

import java.net.URI;

public class SnsProducerException extends AbstractThrowableProblem {

    private static final URI TYPE = URI.create("https://example.org/bad-request");

    public SnsProducerException(String message) {

        super(TYPE, "snsProducerException", Status.BAD_REQUEST, message);
    }

}