package com.serasaconsumidor.antifraude.score.dtos.lgpd;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class OriginDto {
    private Integer id;
    private String type;
    private String mode;
}
