package com.serasaconsumidor.antifraude.score.config.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.serasaconsumidor.antifraude.score.config.security.impl.CryptoSymmetricImpl;

@Configuration
public class CryptoConfig {

    @Value("${security.encryption.cryptIv}")
    String cryptoIv;
    @Value("${security.encryption.cryptKey}")
    String cryptoKey;

    @Bean
    public CryptoSymmetricImpl cryptoSymmetric() {
        return new CryptoSymmetricImpl(cryptoIv, cryptoKey);
    }
}