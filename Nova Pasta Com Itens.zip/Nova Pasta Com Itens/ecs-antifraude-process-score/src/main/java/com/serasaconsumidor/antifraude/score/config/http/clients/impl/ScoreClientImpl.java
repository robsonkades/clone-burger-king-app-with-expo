package com.serasaconsumidor.antifraude.score.config.http.clients.impl;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import com.serasaconsumidor.antifraude.score.config.http.BaseClient;
import com.serasaconsumidor.antifraude.score.config.http.clients.ScoreClient;
import com.serasaconsumidor.antifraude.score.config.http.clients.ScoreClientIdEnum;
import com.serasaconsumidor.antifraude.score.dtos.score.ScoreNumberDto;
import com.serasaconsumidor.antifraude.score.dtos.score.RequestScoreDto;
import com.serasaconsumidor.antifraude.score.dtos.score.ResponseScoreHistoryDto;
import com.serasaconsumidor.antifraude.score.dtos.score.ScoreBatchDto;

@Slf4j
@Service
public class ScoreClientImpl extends BaseClient implements ScoreClient {

    private static final String HISTORY_URN = "/score/history/v1/internal";
    private static final String NUMBER_URN = "/score/number/v1/internal";

    @Override
    public Optional<ScoreNumberDto> getScore(ScoreBatchDto requestScoreDto, ScoreClientIdEnum scoreClientId) {
        try {
            final HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.add("X-Score-Client-Id", scoreClientId.getValue());

            final HttpEntity<Object> requestEntity = new HttpEntity<>(requestScoreDto, httpHeaders);
            final String url = clientProperties.getScoreNumberUrl() + NUMBER_URN;

            ResponseEntity<ScoreNumberDto> responseEntity =
                    restTemplate.exchange(
                            url,
                            HttpMethod.POST,
                            requestEntity,
                            ScoreNumberDto.class
                    );

            if (responseEntity.getBody() == null) {
                log.error("the score response body returned null for user id {}", requestScoreDto.getUserId());
                return Optional.empty();
            }
            return Optional.ofNullable(responseEntity.getBody());
        } catch (Exception e) {
            log.error("There was an error when trying to retrieve score information from user {}. Client returned {}", requestScoreDto.getUserId(), e.getMessage());
            return Optional.empty();
        }
    }

    @Override
    public Optional<List<ResponseScoreHistoryDto>> listHistory(RequestScoreDto requestScoreDto, ScoreClientIdEnum scoreClientId) {
        try {
            final HttpHeaders httpHeaders = new HttpHeaders();
            httpHeaders.add("X-Score-Client-Id", scoreClientId.getValue());

            final HttpEntity<Object> requestEntity = new HttpEntity<>(requestScoreDto, httpHeaders);
            final String url = clientProperties.getScoreHistoryUrl() + HISTORY_URN;

            ResponseEntity<ResponseScoreHistoryDto[]> responseEntity =
                    restTemplate.exchange(
                            url,
                            HttpMethod.POST,
                            requestEntity,
                            ResponseScoreHistoryDto[].class
                    );

            if (responseEntity.getBody() == null) {
                log.error("the score response body returned null for user id {}", requestScoreDto.getUserId());
                return Optional.of(new ArrayList<>());
            }

            return Optional.ofNullable(Arrays.asList(responseEntity.getBody()));
        } catch (Exception e) {
            log.warn("There was an error when trying to retrieve score history information from user {}. Client returned {}", requestScoreDto.getUserId(), e.getMessage());
            throw new RestClientException("There was an error when trying to retrieve score history information from user. " + e.getMessage());
        }
    }
}