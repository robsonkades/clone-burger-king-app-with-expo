package com.serasaconsumidor.antifraude.score.config;

import lombok.experimental.UtilityClass;

@UtilityClass
public class Events {

    public static final String SCORE_WITHOUT_VARIATION = "3151";
    public static final String SCORE_WITH_VARIATION = "3152";
    public static final String REQUEST_SCORE_FREEMIUM_BATCH = "3171";
    public static final String SCORE_EVENT = "3154";
}
