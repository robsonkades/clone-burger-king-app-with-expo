package com.serasaconsumidor.antifraude.score.services.impl;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import com.serasaconsumidor.antifraude.score.config.http.clients.ScoreClient;
import com.serasaconsumidor.antifraude.score.config.http.clients.ScoreClientIdEnum;
import com.serasaconsumidor.antifraude.score.config.redis.RedisManager;
import com.serasaconsumidor.antifraude.score.dtos.score.RequestScoreDto;
import com.serasaconsumidor.antifraude.score.dtos.score.ResponseScoreHistoryDto;
import com.serasaconsumidor.antifraude.score.dtos.score.UpdatedScoreMessageDto;
import com.serasaconsumidor.antifraude.score.dtos.subscription.SubscriptionDto;
import com.serasaconsumidor.antifraude.score.services.CreateScoreAlertService;
import com.serasaconsumidor.antifraude.score.services.ProcessScoreUpdatedService;
import com.serasaconsumidor.antifraude.score.services.StackEventsService;
import com.serasaconsumidor.antifraude.score.utils.Constants;
import com.serasaconsumidor.antifraude.score.utils.LgpdBuilder;

import static com.serasaconsumidor.antifraude.score.config.Events.SCORE_WITHOUT_VARIATION;

@Service
@AllArgsConstructor
@Slf4j
public class ProcessScoreUpdatedServiceImpl implements ProcessScoreUpdatedService {

    private final CreateScoreAlertService createScoreAlertService;
    private final ApplicationEventPublisher eventPublisher;
    private final LgpdBuilder lgpdBuilder;
    private final ScoreClient scoreClient;
    private final StackEventsService stackEventsService;
    private final RedisManager redisManager;

    @Override
    public void execute(UpdatedScoreMessageDto updatedScoreMessageDto) {
        var updatedScore = updatedScoreMessageDto.getData();
        var subscription = updatedScore.getSubscription();

        log.info("Processing starting to score to userId {}", subscription.getUserId());

        var hasNotified = redisManager.hasKey(Constants.getScoreMonitoringCacheKey(subscription.getSubscriptionCode()));

        if (hasNotified) {
            log.info("user has already been notified {}", subscription.getUserId());
            return;
        }

        var scoreHistoryDto = RequestScoreDto
                .builder()
                .document(subscription.getDocument())
                .userId(subscription.getUserId())
                .build();

        Optional<List<ResponseScoreHistoryDto>> scoreHistory = scoreClient.listHistory(scoreHistoryDto, ScoreClientIdEnum.PREMIUM_BATCH);

        scoreHistory.ifPresent((scoreUpdatedList) -> {
            ResponseScoreHistoryDto recentScore = scoreUpdatedList.get(0);

            if (recentScore.getLocalDate().equals(LocalDate.now().minusDays(1)) || recentScore.getLocalDate().equals(LocalDate.now())) {

                if (Objects.nonNull(recentScore.getModel()) &&
                        recentScore.getModel().equalsIgnoreCase("hspn_score") &&
                        scoreUpdatedList.size() > 1 &&
                        Objects.nonNull(scoreUpdatedList.get(1).getModel()) &&
                        !scoreUpdatedList.get(1).getModel().equalsIgnoreCase("hspn_score")) {

                    createScoreAlertService.execute(subscription, recentScore, true);
                    saveRedis(subscription);

                } else {
                    if (recentScore.getVarianceAbsolute().intValue() >= Constants.SCORE_VARIANCE_NOTIFICATION) {

                        createScoreAlertService.execute(subscription, recentScore, false);
                        saveRedis(subscription);

                        var event = lgpdBuilder.constructLgpdDto(subscription, recentScore);
                        eventPublisher.publishEvent(event);
                    } else {
                        stackEventsService.sendMessage(subscription, SCORE_WITHOUT_VARIATION, recentScore.getScore().toBigInteger(), recentScore.getVarianceAbsolute().toBigInteger());
                        log.info("Skip score process to userId {}, variance score {}", subscription.getUserId(), recentScore.getVariance());
                    }
                }

            }
        });
    }

    private void saveRedis(SubscriptionDto subscription) {
        var cacheKey = Constants.getScoreMonitoringCacheKey(subscription.getSubscriptionCode());
        redisManager.setValue(cacheKey, subscription.getSubscriptionCode(), Constants.CACHE_EXPIRATION_SCORE_MONITORING);
    }
}
