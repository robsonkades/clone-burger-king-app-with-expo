package com.serasaconsumidor.antifraude.score.dtos.subscription;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.UUID;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class SubscriptionDto {

    private Long id;
    private String document;
    private String name;
    private String email;
    private String phone;
    private String subscriptionCode;
    private Integer partnerId;
    private Integer planId;
    private UUID userId;
    private String planExternalId;
    private LocalDateTime previewedCancelDate;
    private Boolean receiveSms;
    private Boolean receiveEmail;
    private Boolean activated;
    private String cancellationReason;
    private LocalDateTime cancellationDate;
    private String originDescription;
}
