package com.serasaconsumidor.antifraude.score.dtos.score;

import lombok.Getter;
import lombok.Setter;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Getter
@Setter
@JsonIgnoreProperties(ignoreUnknown = true)
public class ScoreNumberDto {
    private long score;
    private String model;
}
