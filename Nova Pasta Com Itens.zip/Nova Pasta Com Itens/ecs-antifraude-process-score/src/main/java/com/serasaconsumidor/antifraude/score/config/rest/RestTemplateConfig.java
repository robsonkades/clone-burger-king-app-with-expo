package com.serasaconsumidor.antifraude.score.config.rest;

import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;

@Configuration
public class RestTemplateConfig {
    private static final long DEFAULT_TIMEOUT = 5000;

    @Bean
    public RestTemplate restTemplate(final RestTemplateBuilder restTemplateBuilder, final RestTemplateInterceptor restTemplateInterceptor) {
        var rest = restTemplateBuilder
                .setConnectTimeout(Duration.ofMillis(DEFAULT_TIMEOUT))
                .setReadTimeout(Duration.ofMillis(DEFAULT_TIMEOUT)).build();
        rest.getInterceptors().add(restTemplateInterceptor);
        return rest;
    }
}