package com.serasaconsumidor.antifraude.score.config.mapper;

import com.serasaconsumidor.antifraude.score.dtos.lgpd.CompanyDto;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.LgpdDto;
import com.serasaconsumidor.antifraude.score.dtos.lgpd.OriginDto;
import com.serasaconsumidor.antifraude.score.dtos.subscription.SubscriptionDto;

public interface LgpdMapper {
    LgpdDto convert(SubscriptionDto subscriptionDto, Object fields, String consultType, String useType, String purposes, OriginDto origin, CompanyDto company);
}
