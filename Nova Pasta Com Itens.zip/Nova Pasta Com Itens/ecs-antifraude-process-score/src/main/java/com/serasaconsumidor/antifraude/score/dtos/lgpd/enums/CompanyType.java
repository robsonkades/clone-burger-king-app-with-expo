package com.serasaconsumidor.antifraude.score.dtos.lgpd.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum CompanyType {
    CUSTOMER("Cliente"),
    PROVIDER("Fornecedor"),
    PARTNER("Parceiro");
    private String description;
}
