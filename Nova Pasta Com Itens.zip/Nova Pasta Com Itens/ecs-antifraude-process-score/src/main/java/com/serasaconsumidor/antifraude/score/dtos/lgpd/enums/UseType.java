package com.serasaconsumidor.antifraude.score.dtos.lgpd.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum UseType {
    INGESTION("Ingestão"),
    CONSUMPTION("Consumo");
    private String description;
}
