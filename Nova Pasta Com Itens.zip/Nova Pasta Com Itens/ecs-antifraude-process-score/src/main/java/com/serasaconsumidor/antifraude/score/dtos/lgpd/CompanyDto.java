package com.serasaconsumidor.antifraude.score.dtos.lgpd;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class CompanyDto {
    private Integer id;
    private String type;
    private String companyName;
    private String cnpj;
}
