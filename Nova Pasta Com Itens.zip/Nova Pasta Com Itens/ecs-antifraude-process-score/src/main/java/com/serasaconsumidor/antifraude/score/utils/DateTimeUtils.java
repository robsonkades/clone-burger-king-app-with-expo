package com.serasaconsumidor.antifraude.score.utils;

import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

@Slf4j
@UtilityClass
public class DateTimeUtils {

    public static String dateFormatter(String date) {
        if (date == null) return "";
        try {
            LocalDate localDate = getLocalDateOfPattern(date,"yyyy-MM-dd");
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            return formatter.format(localDate);
        } catch (Exception e) {
            log.error("Error converting date {} of pattern yyyy-MM-dd.", date);
            return dateTimeFormatter(date);
        }
    }

    public static String dateTimeFormatter(String dateTime) {
        try {
            if (dateTime == null) return "";
            LocalDate localDate = getLocalDateOfPattern(dateTime,"yyyy-MM-dd'T'HH:mm:ss");
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            return formatter.format(localDate);
        } catch (Exception e) {
            log.error("Error converting date {} of pattern yyyy-MM-dd'T'HH:mm:ss.", dateTime);
            return "";
        }
    }

    public static String dateTimeFormatterToMonthYear(String dateTime) {
        if (dateTime == null) return "";
        LocalDate localDate = getLocalDateOfPattern(dateTime,"yyyy-MM-dd'T'HH:mm:ss");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/yyyy");
        return formatter.format(localDate);
    }

    public static LocalDate getLocalDateOfPattern(String date, String pattern) {
        if (date == null) return LocalDate.now();
        return LocalDate.parse(date, DateTimeFormatter.ofPattern(pattern));
    }

    public static String getMonthDescription(LocalDate date) {
        if (date == null) return "";
        return DateTimeFormatter.ofPattern("LLL", Locale.forLanguageTag("pt-br")).format(date).toUpperCase();
    }

    public static String dateFormatterToDateTime(String date) {
        if (date == null) return "";
        LocalDate localDate;
        try {
            localDate = getLocalDateOfPattern(date, "yyyy-MM-dd");
        } catch(Exception ex) {
            localDate = getLocalDateOfPattern(date, "yyyy-MM-dd'T'HH:mm:ss");
        }
        LocalDateTime localDateTime = LocalDateTime.of(localDate, LocalTime.of(0,0,0,0));
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.0000");
        return formatter.format(localDateTime);
    }

    public static LocalDate dateFormatterToLocalDate(String date) {
        if (date == null) return null;
        LocalDate localDate;
        try {
            localDate = getLocalDateOfPattern(date, "yyyy-MM-dd");
        } catch(Exception ex) {
            localDate = getLocalDateOfPattern(date, "yyyy-MM-dd'T'HH:mm:ss");
        }
        return localDate;
    }

    public static String localDateTimeToString(LocalDateTime localDateTime) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss-0300");
        return formatter.format(localDateTime);
    }

}
