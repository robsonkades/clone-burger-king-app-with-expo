package com.serasaconsumidor.antifraude.score.config.sqs;

import com.serasaconsumidor.antifraude.score.exceptions.SqsConsumerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.ErrorHandler;

@Service
public class SqsErrorHandler implements ErrorHandler {
    private static final Logger LOGGER = LoggerFactory.getLogger(SqsErrorHandler.class);

    @Override
    public void handleError(Throwable throwable) {
        LOGGER.error("An error has occurred in the transaction");
        throw new SqsConsumerException(throwable.getMessage());
    }
}

