package com.serasaconsumidor.antifraude.score.dtos.stackevents;

import com.serasaconsumidor.antifraude.score.dtos.stackevents.data.DataDto;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StackEventDto {
    private String document;
    private String eventCode;
    private String subscriptionCode;
    private String userId;
    private String serviceOrigin;
    private String userType;
    private String clientOrigin;
    private DataDto data;
}
