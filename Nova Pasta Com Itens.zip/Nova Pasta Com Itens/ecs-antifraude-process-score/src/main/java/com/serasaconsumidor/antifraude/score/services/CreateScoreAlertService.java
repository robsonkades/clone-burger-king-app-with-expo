package com.serasaconsumidor.antifraude.score.services;

import com.serasaconsumidor.antifraude.score.dtos.score.ResponseScoreHistoryDto;
import com.serasaconsumidor.antifraude.score.dtos.subscription.SubscriptionDto;

public interface CreateScoreAlertService {
    void execute(SubscriptionDto subscription, ResponseScoreHistoryDto scoreHistoryDto, boolean newScore);
}
