package com.serasaconsumidor.antifraude.score.dtos.delivery;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.serasaconsumidor.antifraude.score.dtos.score.ScoreMessageDto;
import lombok.Builder;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class ScoreAlertDto {
    private Date generationDate;
    private long score;
    private ScoreMessageDto message;
    private boolean hasIncreased;
    private boolean newScore;
}
