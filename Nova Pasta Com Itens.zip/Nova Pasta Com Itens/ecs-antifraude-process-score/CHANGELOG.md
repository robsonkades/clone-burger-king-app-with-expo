# 2.0.0
[31/03/2021]
## Quebras de compatibilidade
* [SPB-797](https://serasaexperian.atlassian.net/browse/SPB-797) - Refatoração do serviço, envio de alerta de alteração de score.

# 1.6.0
[17/03/2021]

## Quebras de compatibilidade

## Novas funcionalidades

## Melhorias

## Correções

## Alterações de banco de dados

## Alterações de dependências