# Process Score

### Environments

|  Name | Required  | Default  |
|---|---|---|
|  ECS_ENVIRONMENT  | x |  |
|  SERVER_PORT  |  | 80  |
|  CONTEXT_PATH  |  |  |
|  AWS_REGION  | x |   |
|  REDIS_HOST | x  |   |
|  REDIS_PORT | x  |   |
|  REDIS_PASSWORD |  x |   |
|  REPORT_SNS_TOPIC_ARN | x  |   |
|  LGPD_SNS_TOPIC_ARN |  x |   |
|  STACK_EVENTS_SNS_TOPIC_ARN |  x |   |
|  SQS_CONCURRENCY | x |  |
|  UPDATED_SCORE_QUEUE | x | |
|  SCORE_HISTORY_URL | x |  |
|  CRYPT_IV | x  |   |
|  CRYPT_KEY |  x |   |